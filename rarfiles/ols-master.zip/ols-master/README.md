# Requirements

- pipenv (for virtual environment)
- python 3.8^
- node 12.^ (for frontend)
- npm (for frontend)
- mysql
- libmysqlclient-dev (for mysql client)
- python3.8-dev
- libpq-dev

# Environment Variables

You can find the environment variables files in the same location as your `settings.py` file. Simply copy the `.env.example` into a new file called `.env` in the same location and adjust your variables.

# Installation

### Project

Initialize and install the environment dependencies.

    pipenv shell

    pipenv install

To start the project go to the project file and run

    python manage.py runserver

To create a super user for admin panel

    python manage.py createsuperuser

### Frontend

Go into the frontend folder and run

    npm install
