from rest_framework import serializers
from assignments.models import SubmittedAssignment, SubmittedAssignmentFiles
from rest_framework.fields import CurrentUserDefault
from .submittedassignmentfileserializer import SubmittedAssignmentFileSerializer
from usermanager.serializers.UserProfileSerializer import UserProfileSerializer


class SubmittedAssignmentSerializer(serializers.ModelSerializer):

    assignment_submitted_files = serializers.SerializerMethodField()

    user = UserProfileSerializer("user.userprofile")

    class Meta:
        model = SubmittedAssignment
        fields = "__all__"

    def get_assignment_submitted_files(self, obj):
        return SubmittedAssignmentFileSerializer(
            instance=SubmittedAssignmentFiles.objects.filter(
                submitted_assignment=obj.id
            ),
            many=True,
        ).data
