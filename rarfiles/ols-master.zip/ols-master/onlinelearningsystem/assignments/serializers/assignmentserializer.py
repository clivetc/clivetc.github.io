from re import sub
from rest_framework import serializers
from assignments.models import Assignment, SubmittedAssignment
from rest_framework.fields import CurrentUserDefault
from .submittedassignmentserializer import SubmittedAssignmentSerializer


class AssignmentSerializer(serializers.ModelSerializer):

    assignment_submitted = serializers.SerializerMethodField()
    submit_count = serializers.SerializerMethodField()
    assignments_submitted = serializers.SerializerMethodField()

    class Meta:
        model = Assignment
        fields = "__all__"

    def get_assignment_submitted(self, obj):
        user = (
            self.context.get("request").user
            if self.context.get("request")
            else self.context.get("user")
        )

        submitted_assignment = SubmittedAssignment.objects.filter(
            assignment=obj, user=user.id
        ).first()
        if submitted_assignment:
            return SubmittedAssignmentSerializer(submitted_assignment).data
        return None

    def get_submit_count(self, obj):

        return obj.submittedassignment_set.count()

    def get_assignments_submitted(self, obj):

        user = (
            self.context.get("request").user
            if self.context.get("request")
            else self.context.get("user")
        )

        if user.userprofile.user_type == "Teacher":
            return SubmittedAssignmentSerializer(
                obj.submittedassignment_set.all(), many=True
            ).data

        return None
