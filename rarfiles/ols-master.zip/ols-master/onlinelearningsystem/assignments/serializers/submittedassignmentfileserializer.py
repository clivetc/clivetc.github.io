from rest_framework import serializers
from assignments.models import SubmittedAssignmentFiles
from rest_framework.fields import CurrentUserDefault
import os


class SubmittedAssignmentFileSerializer(serializers.ModelSerializer):

    size = serializers.SerializerMethodField()
    type = serializers.SerializerMethodField()

    class Meta:
        model = SubmittedAssignmentFiles
        fields = "__all__"

    def get_size(self, obj):
        return obj.path.size

    def get_type(self, obj):
        fileName, fileExtension = os.path.splitext(obj.path.name)
        print(obj.path)
        return fileExtension