# Create your views here.
from rest_framework import serializers, viewsets
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from .helpers.assignmentmanager import AssignmentManager
from .serializers.submittedassignmentserializer import SubmittedAssignmentSerializer


from .models import (
    Assignment,
    AssignmentFile,
    SubmittedAssignment,
    SubmittedAssignmentFiles,
)
from .serializers.assignmentserializer import AssignmentSerializer


class AssignmentViewSet(viewsets.ModelViewSet):

    queryset = Assignment.objects.all()
    serializer_class = AssignmentSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=["POST"])
    def submit(self, request, **kwargs):
        user = request.user
        assignment = self.get_object()

        try:
            submitted_assignment = AssignmentManager.submit_assignment(
                assignment, user, assignment.course, assignment.assignmentfile_set.all()
            )

            assignment.assignmentfile_set.all().delete()
            return Response(
                {"type": "success", "message": "Assignment Successfully Submitted"}, 200
            )
        except Exception as e:  # work on python 3.x
            return Response({"type": "error", "message": str(e)})

    @action(detail=True, methods=["POST"])
    def upload(self, request, **kwargs):

        user = request.user
        assignment = self.get_object()
        file = request.FILES["file"]
        fileTitle = file.name
        attachment = AssignmentFile(
            title=fileTitle, path=file, assignment=assignment, user=user
        )

        try:
            attachment.full_clean()
            attachment.save()
            return Response(
                {
                    "type": "success",
                    "message": "File Successfully Uploaded",
                    "path": attachment.path.url,
                    "id": attachment.id,
                },
                200,
            )
        except:
            return Response({}, 400)

    @action(detail=True, methods=["GET"])
    def files(self, request, **kwargs):

        user = request.user
        print(request.user)
        assignment = self.get_object()
        submitted_assignment = assignment.submittedassignment_set.filter(
            user=user, assignment=assignment
        ).first()

        print(submitted_assignment)
        serializer = SubmittedAssignmentSerializer(submitted_assignment)

        return Response(serializer.data, 200)

    @action(detail=True, methods=["POST"])
    def remove(self, request, **kwargs):
        user = request.user
        assignment = self.get_object()
        file = request.data.get("file")
        print(file)
        saf = SubmittedAssignmentFiles.objects.get(pk=file["file_id"])

        if not saf:
            return Response({"type": "error", "message": "File not found"}, 400)

        saf.delete()

        return Response(
            {"type": "success", "message": "File Removed Successfully"}, 200
        )


class SubmittedAssignmentViewSet(viewsets.ModelViewSet):

    queryset = SubmittedAssignment.objects.all()
    serializer_class = SubmittedAssignmentSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=["GET"])
    def files(self, request, **kwargs):

        submitted_assignment = self.get_object()

        serializer = SubmittedAssignmentSerializer(submitted_assignment)

        return Response(serializer.data, 200)
