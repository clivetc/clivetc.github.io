from assignments.models import SubmittedAssignmentFiles
from django import forms


class UploadAssignmentFileForm(forms.ModelForm):
    class Meta:
        model = SubmittedAssignmentFiles
        fields = ("title", "file")
