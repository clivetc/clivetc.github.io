from django import forms
from datetime import datetime


class CreateAssignmentForm(forms.Form):

    assignment_title = forms.CharField()
    assignment_description = forms.CharField()
    assignment_due = forms.DateTimeField(input_formats=["%m/%d/%Y %I:%M %p"])
    assignment_points = forms.CharField()

    def clean_due(self):
        return self.cleaned_data["assignment_due"]

    def clean_assignment_title(self):
        return self.cleaned_data["assignment_title"]

    def clean_assignment_description(self):
        return self.cleaned_data["assignment_description"]

    def clean_assignment_points(self):
        return self.cleaned_data["assignment_points"]
