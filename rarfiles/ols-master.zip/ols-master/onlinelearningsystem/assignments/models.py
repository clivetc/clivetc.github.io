from django.db import models
from django.contrib.auth.models import User
from Courses.models import Course


def submitted_assignment_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return "submitted_assignments/assignment_{0}/{1}".format(
        instance.submitted_assignment.id, filename
    )


def assignment_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return "assignment_files/assignment_{0}/{1}".format(
        instance.assignment.id, filename
    )


class Assignment(models.Model):

    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    assignment_title = models.CharField(max_length=100)
    assignment_description = models.TextField(max_length=250)
    assignment_due = models.DateTimeField(null=False)
    assignment_points = models.IntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)


class AssignmentFile(models.Model):
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING)
    title = models.CharField(max_length=250)
    path = models.FileField(upload_to=assignment_directory_path)


class SubmittedAssignment(models.Model):

    user = models.ForeignKey(User, on_delete=models.DO_NOTHING)
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    accepted = models.BooleanField(default=False)
    submitted_on = models.DateTimeField(auto_now=True)
    grade = models.IntegerField(default=0)


class SubmittedAssignmentFiles(models.Model):
    submitted_assignment = models.ForeignKey(
        SubmittedAssignment, on_delete=models.CASCADE
    )
    title = models.CharField(max_length=250)
    path = models.FileField(upload_to=submitted_assignment_directory_path)
