from typing import List, Union


from ..models import (
    Assignment,
    AssignmentFile,
    SubmittedAssignment,
    SubmittedAssignmentFiles,
)
from Courses.models import Course
from django.contrib.auth.models import User
from django.db.models import QuerySet


class AssignmentManager:
    @staticmethod
    def get_assignment(assignment_id: int) -> Assignment:
        return Assignment.objects.filter(pk=assignment_id)

    @staticmethod
    def get_course_assignments(course: Course) -> QuerySet:
        return Assignment.objects.filter(course=course)

    @staticmethod
    def create_assignment(assignment: Assignment) -> Assignment:
        assignment.save()
        return assignment

    @staticmethod
    def set_assignment_status(submitted_assignment: SubmittedAssignment):

        pass

    @staticmethod
    def grade_assignment(submitted_assignment: int, grade: int):
        sa = SubmittedAssignment.objects.get(pk=submitted_assignment)
        sa.grade = grade
        sa.accepted = True
        sa.save()
        return sa

    @staticmethod
    def remove_assignment():
        pass

    @staticmethod
    def update_assignment(submitted_assignment: SubmittedAssignment, assignment_files):
        pass

    @staticmethod
    def extend_deadline():
        pass

    @staticmethod
    def attach_file():
        pass

    @staticmethod
    def submit_assignment(
        assignment: Assignment,
        user: User,
        course: Course,
        assignment_files: Union[QuerySet, List[AssignmentFile]],
    ) -> Assignment:

        intial_sa = SubmittedAssignment.objects.filter(
            assignment=assignment, user=user
        ).first()
        if not intial_sa:
            sa = SubmittedAssignment(assignment=assignment, course=course, user=user)
            sa.save()
            for file in assignment_files:
                SubmittedAssignmentFiles.objects.create(
                    title=file.title, path=file.path, submitted_assignment=sa
                )
        else:
            AssignmentManager.update_assignment(intial_sa, assignment_files)

        return Assignment
