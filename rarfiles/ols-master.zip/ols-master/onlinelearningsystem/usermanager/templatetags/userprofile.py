from django import template
from django.core import serializers
from usermanager.helpers.usermanager import UserManager
from onlinelearningsystem.middleware.globalrequest import get_current_request
import json

register = template.Library()


@register.simple_tag
def user_profile():
    up = None
    if get_current_request().user.is_authenticated:
        user = get_current_request().user
        up = get_data_as_json(UserManager.getUserProfile(user))[0]
        return up

    return up


def get_data_as_json(data):
    return json.loads(serializers.serialize("json", [data], ensure_ascii=False))