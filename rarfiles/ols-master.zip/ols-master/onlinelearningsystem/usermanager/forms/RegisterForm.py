from django import forms
from django.core.validators import EmailValidator


class RegisterForm(forms.Form):

    types = (("Student", "STUDENT"), ("Teacher", "TEACHER"))

    user_type = forms.ChoiceField(
        error_messages={"required": "Please select a user type"},
        required=True,
        choices=types,
    )
    first_name = forms.CharField(
        error_messages={"required": "Please enter your first name"}, required=True
    )
    last_name = forms.CharField(
        error_messages={"required": "Please enter your last name"}, required=True
    )
    email = forms.EmailField(
        error_messages={"required": "Please enter your email"}, required=True
    )
    password = forms.CharField(
        error_messages={"required": "please enter a password"}, required=True
    )
    confirm_password = forms.CharField(
        error_messages={"required": "Please confirm your password"}, required=True
    )

    agreement_accepted = forms.BooleanField(
        required=True,
        error_messages={"required": "Please accept the Terms and Conditions"},
    )
