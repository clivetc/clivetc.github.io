from django import forms


class LoginForm(forms.Form):

    username = forms.CharField(
        error_messages={"required": "Please enter your username"}, required=True
    )

    password = forms.CharField(
        error_messages={"required": "please enter your password"}, required=True
    )
