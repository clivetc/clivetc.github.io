from abc import ABC, abstractmethod
from django.contrib.auth.models import User


class UserManagerInterface(ABC):
    @staticmethod
    @abstractmethod
    def loginUser(request, username: str, password: str) -> bool:

        pass

    @staticmethod
    @abstractmethod
    def registerUser(username: str, password: str, confirm: str) -> User:

        pass

    @staticmethod
    @abstractmethod
    def changePassword(username: str, password: str, confirm: str):

        pass

    @staticmethod
    @abstractmethod
    def resetPassword(username: str):

        pass