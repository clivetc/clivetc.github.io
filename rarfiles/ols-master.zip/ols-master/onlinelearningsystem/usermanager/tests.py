from django.test import TestCase, RequestFactory, Client
from .helpers.usermanager import UserManager
from django.contrib.auth.models import User
from django.contrib.sessions.middleware import SessionMiddleware

# Create your tests here.


class UserManagerTestCase(TestCase):
    def setUp(self):

        self.client = Client()
        pass

    def test_user_can_log_in(self):

        user = UserManager.registerUser("Unal", "Password", "Password")
        self.assertIsInstance(user, User)

        self.assertTrue(self.client.login(username="Unal", password="Password"))

    def test_user_fails_login(self):

        request = self.client.get("/user/login")
        self.assertFalse(
            UserManager.loginUser(request, "Unal", "campio1234"),
        )

    def test_user_can_register(self):

        user = UserManager.registerUser("Unal", "Password", "Password")
        self.assertIsInstance(user, User)
