from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from usermanager.interfaces.UserManagerInterface import UserManagerInterface
from usermanager.models import UserProfile
from errors.ConfirmError import ConfirmError


class UserManager(UserManagerInterface):
    @staticmethod
    def loginUser(request, username: str, password: str) -> bool:
        user = authenticate(username=username, password=password)

        if not user:
            return None

        login(request, user)
        return True

    @staticmethod
    def registerUser(request, username: str, password: str) -> User:

        user = User.objects.create_user(
            username=username,
            password=password,
            email=username,
            first_name=request.get("first_name"),
            last_name=request.get("last_name"),
        )

        return user

    @staticmethod
    def changePassword(username: str, password: str, confirm: str):

        return

    @staticmethod
    def resetPassword(username: str):

        return

    @staticmethod
    def createProfile(data, user: User):

        print(data)
        up = UserProfile(
            first_name=data.get("first_name"),
            last_name=data.get("last_name"),
            user_type=data.get("user_type"),
            user=user,
        )

        if up:
            up.save()

        return

    @staticmethod
    def getUserProfile(user: User):
        return UserProfile.objects.get(user=user)

    @staticmethod
    def logoutUser(request):
        logout(request)
        return True
