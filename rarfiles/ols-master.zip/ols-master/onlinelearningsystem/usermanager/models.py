from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class UserProfile(models.Model):
    user_types = models.TextChoices("user_type", "STUDENT TEACHER")

    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    user_type = models.CharField(
        max_length=50, blank=False, choices=user_types.choices, default="STUDENT"
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, null=True)
