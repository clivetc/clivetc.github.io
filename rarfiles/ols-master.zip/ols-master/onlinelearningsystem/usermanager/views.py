from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from .helpers.usermanager import UserManager
from .forms.RegisterForm import RegisterForm
from .forms.LoginForm import LoginForm
from .models import UserProfile
from django.core import serializers
import json

# Create your views here.

from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework import viewsets
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.request import Request
from rest_framework.decorators import action
from posts.models import Post
from posts.serializers.postserializer import PostSerializer
from posts.helpers.PostManager import PostManager
from Courses.models import Course
from django.contrib.auth.models import User
from .serializers.UserSerializer import UserSerializer

# Create your views here.


class UserViewSet(viewsets.GenericViewSet):

    queryset = User.objects.all()
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer

    @action(detail=False, methods=["GET"])
    def user_recent_posts(self, request: Request):
        user = request.user
        user_courses = Course.objects.filter(user=user)

        data = []
        for user_course in user_courses:
            post = user_course.post_set.order_by("-created").first()

            if post:
                data.append(PostSerializer(post).data)

        return Response(data=data)


def user_login_view(request, *args, **kwargs):

    if request.user.is_authenticated:
        return HttpResponseRedirect("/user/dashboard")

    if request.method == "POST":

        form = LoginForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = UserManager.loginUser(request, username, password)

            if user:
                return HttpResponseRedirect("/user/dashboard")
            else:
                return render(
                    request,
                    "user/login.html",
                    {"error": "Your Username/Password is incorrect"},
                )
        else:
            return render(
                request,
                "user/login.html",
                {"errors": form.errors.as_json(escape_html=True)},
            )

    context = {}
    return render(request, "user/login.html", context)


def user_register_view(request, *args, **kwargs):

    if request.user.is_authenticated:
        return HttpResponseRedirect("/user/dashboard")

    if request.method == "POST":

        form = RegisterForm(request.POST)

        if form.is_valid():
            user = UserManager.registerUser(
                request.POST,
                request.POST["email"],
                request.POST["password"],
            )

            if user:
                UserManager.createProfile(request.POST, user)
                return render(
                    request,
                    "user/login.html",
                    {
                        "success": "Congratulations you have successfully created your account"
                    },
                )

        else:
            return render(
                request,
                "user/register.html",
                {"errors": form.errors.as_json(escape_html=True)},
            )

    return render(request, "user/register.html")


def user_dashboard_view(request, *args, **kwargs):
    if request.user.is_authenticated:
        return render(
            request,
            "user/dashboard.html",
        )

    return HttpResponseRedirect("/user/login")


def user_logout(request, *args, **kwargs):
    if request.user.is_authenticated:
        UserManager.logoutUser(request)
        return HttpResponseRedirect("/")
    return HttpResponseRedirect(request.META.get("HTTP_REFERER", "/"))


def user_profile(request, *args, **kwargs):
    res = HttpResponse()

    if request.user.is_authenticated:
        user_profile = UserProfile.objects.get(user=request.user)
        res.status_code = 200
        res.content = serializers.serialize("json", [user_profile])
        return res

    res.status_code = 401
    res.reason_phrase = "You are not authorized to view this resource"
    return res


def get_data_as_json(data):
    return json.loads(serializers.serialize("json", [data], ensure_ascii=False))