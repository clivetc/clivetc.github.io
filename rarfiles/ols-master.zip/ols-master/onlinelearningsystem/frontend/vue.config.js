const BundleTracker = require("webpack-bundle-tracker");

module.exports = {
  publicPath: getPublicPath(),
  outputDir: require("path").resolve("./dist"),
  runtimeCompiler: true,
  css: {
    loaderOptions: {
      sass: {
        prependData: `
            @import "@/sass/_variables.scss";
            @import "@/sass/_base.scss";
            
            `,
      },
    },
  },
  chainWebpack: (config) => {
    config.output.filename("bundle.js");
    config.optimization.splitChunks(false);
    config
      .plugin("BundleTracker")
      .use(BundleTracker, [{ filename: "./" + getStatsFileName() }]);
    config.resolve.alias.set("__STATIC__", "static");
    config.devServer
      .public("http://0.0.0.0:8080")
      .host("0.0.0.0")
      .port(8080)
      .hotOnly(true)
      .watchOptions({ poll: 1000 })
      .https(false)
      .headers({ "Access-Control-Allow-Origin": ["*"] });
  },
};

function getPublicPath() {
  if (isDevelopment()) {
    return "http://127.0.0.1:8080/";
  }

  return "https://ols-staging.herokuapp.com/static/";
}

function getStatsFileName() {
  if (isDevelopment()) {
    return "webpack-stats.json";
  }

  return "webpack-stats-prod.json";
}

function isDevelopment() {
  return process.env.NODE_ENV === "development";
}
