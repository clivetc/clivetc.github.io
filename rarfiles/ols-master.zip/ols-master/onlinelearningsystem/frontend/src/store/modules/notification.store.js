
const state = {
    notifications: []
};

const getters = {
    getNotifications(state) {
        return state.notifications;
    }
}

const actions = {
    display({commit}, payload) {
        commit("appendToNotifications", payload);
    }
}

const mutations = {
    appendToNotifications(state, payload) {
        state.notifications.push(payload)
    }
}


export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}