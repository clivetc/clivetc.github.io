import axios from "../../httpClient/axios";

const state = {
   recentPosts: [],
};

const getters = {
    getRecentPostsState(state) {
        return state.recentPosts;
    },

}

const actions = {
    async getRecentPosts({commit}) {
        return axios.get('/api/user/user_recent_posts/').then(res => {
            commit('setRecentPostsState', res.data)
        });
    }
}


const mutations = {
    setRecentPostsState(state, payload) {
        state.recentPosts = payload
    },
}


export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}