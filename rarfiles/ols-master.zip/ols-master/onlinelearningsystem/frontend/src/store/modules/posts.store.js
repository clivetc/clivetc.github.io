import axios from "../../httpClient/axios";
const state = {
    posts: [],
};

const getters = {
    getPostsState(state) {
        return state.posts;
    },

}

const actions = {
    async joinCourse({commit}, payload) {
        await axios.post('/api/Posts/join/', payload).then((res) => {
                commit('setPostsState', res.data.Posts);
        });
    }
}


const mutations = {
    setPostsState(state, payload) {
        state.posts = payload
    },
}


export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}