/* eslint-disable */
import axios from "../../httpClient/axios";

const state = {
    assignments: [],
    files: [],
};

const getters = {
    getAssignmentsState(state) {
        return state.assignments;
    },

    getFilesState(state) {
        return state.files;
    }
}

const actions = {
    async createAssignment({ commit }, payload) {
        console.log(payload);
        let res = await axios.post(`/api/courses/${payload.course_id}/create_assignment/`, {
            assignment_title: payload.assignment_title,
            assignment_description: payload.assignment_description,
            assignment_points: payload.assignment_points,
            assignment_due: payload.assignment_due
        }, {
            headers: {
                'X-CSRFToken': window.csrftoken
            },
        });
        commit('setAssignmentsState', res);
        return res;
    },

    setFilesToUpload({ commit }, payload) {
        console.log(payload);
        commit('setFilesState', payload);
    },

    async removeFile({ commit }, payload) {
        console.log(payload.link);
        let res = await axios.post(payload.link, { file: payload.file });
        return res;
    }
}


const mutations = {
    setAssignmentsState(state, payload) {
        state.assignments = payload;
    },

    setFilesState(state, payload) {
        state.files = payload;
    }

}


export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}