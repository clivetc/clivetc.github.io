import axios from "../../httpClient/axios";
const state = {
    courses: [],
    courseInfo: [],
    coursePostsState: [],
    course: {}
};

const getters = {
    getCoursesState(state) {
        return state.courses;
    },

    getCourseInfoState(state) {
        return state.courseInfo;
    },

    getCoursePostsState(state) {
        return state.coursePostsState
    },

    getCourseState(state) {
        return state.course
    }
}

const actions = {
    async getUserSpecificCourses({ commit }) {
        await axios.get('/api/courses/specific/?format=json').then((res) => {
            commit('setCoursesState', res.data);
        });
    },

    async joinCourse({ commit }, payload) {
        await axios.post('/api/courses/join/', payload).then((res) => {
            commit('setCoursesState', res.data.courses);
        });
    },

    async getCoursePosts({ commit }, payload) {
        await axios.get(`/api/courses/${payload}/post_list/?format=json`).then(res => {
            commit('setCoursePostsState', res.data);
        });
    },

    async createPost({ commit }, payload) {
        let res = await axios.post(`/api/courses/${payload.course_id}/add_post/`, {
            course_id: payload.course_id,
            content: payload.content,
            post_type: payload.post_type,
        });
        commit('setCoursePostsState', res.data.posts);

        return true;
    }
}


const mutations = {
    setCoursesState(state, payload) {
        state.courses = payload
    },

    setCourseInfoState(state, payload) {
        state.courseInfo = payload[0].fields
        state.course = payload[0]
    },

    setCoursePostsState(state, payload) {
        state.coursePostsState = payload
    }
}


export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}