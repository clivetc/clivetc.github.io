
import Vue from 'vue';
import Vuex from 'vuex';
import coursesStore from "./modules/courses.store";
import notificationStore from "./modules/notification.store"
import postsStore from "./modules/posts.store"
import userStore from './modules/user.store'
import assignmentStore from './modules/assignment.store'
Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    coursesStore,
    notificationStore,
    postsStore,
    userStore,
    assignmentStore
  },

  // Making sure that we're doing
  // everything correctly by enabling
  // strict mode in the dev environment.
  strict: process.env.NODE_ENV !== 'production',

});
