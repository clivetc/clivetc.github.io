export default {
  wrapperValue: "1440",
  isAuth: window.isAuth,
  userProfile: window.userProfile,
  csrfToken: window.csrftoken
};
