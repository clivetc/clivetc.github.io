<template>
  <div
    class="col-2 pt-4 pb-4 mt-5 d-flex flex-column align-items-center"
    style="min-width: 200px"
  >
    <div v-if="userProfile.user_type == 'Teacher'">
      <ClassTeacherActions></ClassTeacherActions>
    </div>
    <div v-else>
      <ClassStudentActions></ClassStudentActions>
    </div>
  </div>
</template>

<script>
import ClassTeacherActions from "./Teacher/ClassTeacherActions";
import ClassStudentActions from "./Student/ClassStudentActions";
export default {
  components: {
    ClassStudentActions,
    ClassTeacherActions,
  },
  props: ["courseInfo"],
  beforeMount() {
    this.$store.commit("coursesStore/setCourseInfoState", this.courseInfo);
  },
};
</script>

<style lang="scss" scoped>
</style>