<template>
  <div
    class="col-2 h-100 pl-0 pr-0 pt-4 pb-4"
    style="
      box-shadow: 3px 3px 5px 1px rgba(0, 0, 0, 0.3);
      min-width: 250px;
      max-width: 350px;
    "
  >
    <div class="d-flex align-items-center justify-content-center mt-4 px-2">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>