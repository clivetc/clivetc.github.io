<template>
  <Container margin="0" padding="0" class="h-100 flex-lg-row flex-column">
    <!-- Login Side Start -->
    <Container padding="40" class="col-lg align-items-lg-center" :row="false">
      <Container width="100%">
        <IconButton
          @clicked="goBack()"
          size="small"
          color="black"
          name="LeftArrow"
        ></IconButton>
      </Container>
      <Container :row="false" width="100%">
        <Container
          width="100%"
          class="justify-content-center justify-content-lg-start"
        >
          <baseheading level="2">Login</baseheading>
        </Container>

        <Container
          class="justify-content-center justify-content-lg-start"
          width="100%"
        >
          <form
            style="padding: 0"
            class="col-md-9 col-sm-10 col-12"
            action="/user/login"
            method="POST"
          >
            <slot></slot>

            <ValidationErrors :errors="errors"></ValidationErrors>

            <Container width="100%">
              <TextInput
                label="Username"
                name="username"
                type="text"
              ></TextInput>
            </Container>
            <Container width="100%">
              <TextInput
                label="Password"
                name="password"
                type="password"
              ></TextInput>
            </Container>
            <Container :left="false" width="100%">
              <TextLink to="/user/forgot">Forgot Password</TextLink>
            </Container>
            <Container
              class="justify-content-center justify-content-lg-start"
              width="100%"
            >
              <div style="width: 12rem">
                <SubmitButton type="compliment">Login</SubmitButton>
              </div>
            </Container>
          </form>
        </Container>
      </Container>
    </Container>
    <!-- Login Side End-->
    <!-- CTA SIDE START -->
    <Container
      padding="58"
      class="align-items-center align-items-lg-start col-lg bg-primary"
      :row="false"
    >
      <baseheading style="margin-bottom: 1.5rem" invert="invert" level="2"
        >Need an account ?</baseheading
      >
      <baseheading invert="invert" level="4"
        >Click here to create an account</baseheading
      >
      <Container
        class="justify-content-center justify-content-lg-start"
        width="12rem"
        :row="false"
      >
        <LinkButton to="/user/register" type="compliment">Register</LinkButton>
      </Container>
    </Container>
    <!-- CTA SIDE END -->
  </Container>
</template>

<script>
import Container from "../layoutComponents/Container";
import IconButton from "../buttonComponents/IconButton";
import LinkButton from "../buttonComponents/LinkButton";
import TextInput from "../formComponents/textInput";
import SubmitButton from "../buttonComponents/SubmitButton";
import TextLink from "../TypographyComponents/TextLink";
import ValidationErrors from "../errorComponents/ValidationErrors";

export default {
  components: {
    Container,
    IconButton,
    LinkButton,
    TextInput,
    SubmitButton,
    TextLink,
    ValidationErrors,
  },

  props: ["errors"],
  methods: {
    goBack() {
      window.location.href = "/";
    },
  },
};
</script>

<style lang="scss" scoped>
</style>