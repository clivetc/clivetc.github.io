<template>
  <div>
    <div>
      <DefaultButton
        size="small"
        type="compliment"
        @clicked="openJoinClassDialogue"
      >
        Share Course
      </DefaultButton>
      <DialogueBox :open="courseBoxState" @close="closeJoinClassDialogue">
        <baseheading level="6">Share this code</baseheading>
        <div
          class="pt-3 pb-3 d-flex justify-content-center align-items-center h-100"
        >
          <baseheading level="5">{{ course.invite_code }}</baseheading>
        </div>
      </DialogueBox>
    </div>
    <div class="mt-3">
      <DefaultButton
        size="small"
        type="compliment"
        @clicked="toggleDrop('assignment')"
      >
        Create Assignment
      </DefaultButton>
      <dropdown-page
        :active="assignmentState"
        @closed="toggleDrop('assignment')"
      >
        <assignment-creation-form></assignment-creation-form>
      </dropdown-page>
    </div>
    <div class="mt-3">
      <DefaultButton
        size="small"
        type="compliment"
        @clicked="toggleDrop('quiz')"
      >
        Create Quiz
      </DefaultButton>
      <dropdown-page :active="quizState" @closed="toggleDrop('quiz')">
      </dropdown-page>
    </div>
  </div>
</template>

<script>
import DefaultButton from "@/components/buttonComponents/DefaultButton";
import DialogueBox from "@/components/popupComponents/DialogueBox";
import { mapGetters } from "vuex";
import DropdownPage from "../../../popupComponents/DropdownPage.vue";
import AssignmentCreationForm from "../../../forms/AssignmentCreationForm.vue";
export default {
  components: {
    DefaultButton,
    DialogueBox,
    DropdownPage,
    AssignmentCreationForm,
  },
  computed: {
    ...mapGetters({
      course: "coursesStore/getCourseInfoState",
    }),
  },

  data() {
    return {
      courseBoxState: false,
      quizState: false,
      assignmentState: false,
    };
  },
  methods: {
    openJoinClassDialogue() {
      this.courseBoxState = true;
    },
    closeJoinClassDialogue() {
      this.courseBoxState = false;
    },
    toggleDrop(value) {
      switch (value) {
        case "quiz":
          this.quizState = !this.quizState;
          break;

        case "assignment":
          this.assignmentState = !this.assignmentState;
          break;
        default:
          break;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
</style>