<template>
  <div
    class="col-2 h-100 pl-0 pr-0 pt-4 pb-4"
    style="
      box-shadow: 3px 3px 5px 1px rgba(0, 0, 0, 0.3);
      min-width: 250px;
      max-width: 350px;
    "
  >
    <base-teacher-sidebar
      v-if="userProfile.user_type == 'Teacher'"
    ></base-teacher-sidebar>
    <base-student-sidebar
      v-if="userProfile.user_type == 'Student'"
    ></base-student-sidebar>
  </div>
</template>

<script>
import BaseStudentSidebar from "../studentdashboard/BaseStudentSidebar.vue";
import BaseTeacherSidebar from "../teacherdashboard/BaseTeacherSidebar.vue";
export default {
  components: { BaseTeacherSidebar, BaseStudentSidebar },
};
</script>

<style lang="scss" scoped>
</style>