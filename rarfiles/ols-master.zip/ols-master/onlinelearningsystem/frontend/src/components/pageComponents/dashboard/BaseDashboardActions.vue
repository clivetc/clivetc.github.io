<template>
  <div
    class="col-2 pt-4 pb-4"
    style="min-width: 200px; max-width: 300px; width: 100%"
  >
    <base-teacher-actions
      v-if="userProfile.user_type == 'Teacher'"
    ></base-teacher-actions>
    <base-student-actions
      v-if="userProfile.user_type == 'Student'"
    ></base-student-actions>
  </div>
</template>

<script>
import BaseStudentActions from "../studentdashboard/BaseStudentActions.vue";
import BaseTeacherActions from "../teacherdashboard/BaseTeacherActions.vue";
export default {
  components: { BaseTeacherActions, BaseStudentActions },
};
</script>

<style lang="scss" scoped>
</style>