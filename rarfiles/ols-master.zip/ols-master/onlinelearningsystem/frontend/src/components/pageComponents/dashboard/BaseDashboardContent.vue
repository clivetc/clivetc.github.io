<template>
  <div class="col pt-4 pb-4" style="">
    <base-teacher-content
      v-if="userProfile.user_type == 'Teacher'"
    ></base-teacher-content>
    <base-student-content
      v-if="userProfile.user_type == 'Student'"
    ></base-student-content>
  </div>
</template>

<script>
import BaseStudentContent from "../studentdashboard/BaseStudentContent.vue";
import BaseTeacherContent from "../teacherdashboard/BaseTeacherContent.vue";
export default {
  components: { BaseTeacherContent, BaseStudentContent },
};
</script>

<style lang="scss" scoped>
</style>