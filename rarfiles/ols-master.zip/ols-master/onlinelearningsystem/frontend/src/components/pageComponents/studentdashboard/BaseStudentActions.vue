<template>
  <div class="mt-5 d-flex flex-column align-items-center">
    <div style="width: 150px">
      <DefaultButton
        size="small"
        type="compliment"
        @clicked="openJoinClassDialogue"
      >
        join a course
      </DefaultButton>
      <DialogueBox :open="courseBoxState" @close="closeJoinClassDialogue">
        <baseheading level="6">Please enter your course code</baseheading>
        <div class="pt-3 pb-3">
          <TextInput @changed="setCourseCode" label="Course Code"></TextInput>
        </div>
        <DefaultButton @clicked="joinCourse" type="compliment">
          Join course
        </DefaultButton>
      </DialogueBox>
    </div>
  </div>
</template>

<script>
import DefaultButton from "../../buttonComponents/DefaultButton";
import DialogueBox from "../../popupComponents/DialogueBox";
import TextInput from "../../formComponents/textInput";

export default {
  components: {
    DefaultButton,
    DialogueBox,
    TextInput,
  },
  mounted() {
    console.log(this.userProfile.user);
  },
  data() {
    return {
      courseBoxState: false,
      courseCode: "",
    };
  },
  methods: {
    openJoinClassDialogue() {
      this.courseBoxState = true;
    },
    closeJoinClassDialogue() {
      this.courseBoxState = false;
    },
    joinCourse() {
      this.$store.dispatch("coursesStore/joinCourse", {
        code: this.courseCode,
        user: this.userProfile.user,
      });
    },

    setCourseCode(value) {
      this.courseCode = value;
    },
  },
};
</script>

<style lang="scss" scoped>
</style>