<template>
  <Wrapper padding="1rem 3rem">
    <div class="w-100 row justify-content-lg-start justify-content-center">
      <form
        action="/user/register"
        method="POST"
        class="h-100 d-flex flex-column align-items-center align-items-lg-start mt-5"
        style="width: 100%; min-width: 250px; max-width: 600px"
      >
        <slot></slot>
        <Container class="mb-5" width="100%" padding="0">
          <IconButton
            @clicked="goBack()"
            size="small"
            color="black"
            name="LeftArrow"
          ></IconButton>
        </Container>
        <baseheading level="2">Register</baseheading>

        <ValidationErrors :errors="errors"></ValidationErrors>

        <div
          class="row justify-content-center justify-content-lg-start"
          style="align-self: unset"
        >
          <div class="col-12 mt-4">
            <SelectInput
              name="user_type"
              :options="selectOptions()"
              label="User Type"
            ></SelectInput>
          </div>
          <div class="col-lg-6 mt-4">
            <TextInput
              name="first_name"
              type="text"
              label="First Name"
            ></TextInput>
          </div>
          <div class="col-lg-6 mt-4">
            <TextInput
              name="last_name"
              type="text"
              label="Last Name"
            ></TextInput>
          </div>
          <div class="col-12 mt-4">
            <TextInput name="email" type="email" label="Email"></TextInput>
          </div>
          <div class="col-12 mt-4">
            <TextInput
              name="password"
              type="password"
              label="Password"
            ></TextInput>
          </div>
          <div class="col-12 mt-4">
            <TextInput
              name="confirm_password"
              type="password"
              label="Confirm Password"
            ></TextInput>
          </div>
          <div class="col-12 mt-5 mb-3">
            <CheckBox
              name="agreement_accepted"
              class="justify-content-center justify-content-lg-start"
              >I accept the
              <TextLink to="/" type="primary"
                >Terms and Conditions</TextLink
              ></CheckBox
            >
          </div>
          <div class="col-4 mt-3 mb-5">
            <SubmitButton type="compliment">Register</SubmitButton>
          </div>
        </div>
      </form>
    </div>
  </Wrapper>
</template>

<script>
import Container from "../layoutComponents/Container";
import IconButton from "../buttonComponents/IconButton";
import TextInput from "../formComponents/textInput";
import Wrapper from "../layoutComponents/Wrapper";
import SubmitButton from "../buttonComponents/SubmitButton";
import SelectInput from "../formComponents/selectInput";
import CheckBox from "../formComponents/checkBox";
import TextLink from "../TypographyComponents/TextLink";
import ValidationErrors from "../errorComponents/ValidationErrors";

export default {
  components: {
    Container,
    IconButton,
    TextInput,
    Wrapper,
    SubmitButton,
    SelectInput,
    CheckBox,
    TextLink,
    ValidationErrors,
  },
  props: {
    errors: {
      type: String,
      default: "",
    },
  },
  methods: {
    goBack() {
      window.location.href = "/";
    },
    selectOptions() {
      return [
        { name: "Student", value: "student" },

        { name: "Teacher", value: "teacher" },
      ];
    },
  },
};
</script>

<style lang="scss" scoped>
</style>