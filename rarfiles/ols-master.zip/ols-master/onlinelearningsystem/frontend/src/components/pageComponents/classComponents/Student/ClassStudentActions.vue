<template>
  <div>
    <DefaultButton size="small" type="compliment">
      Submit Assignment
    </DefaultButton>
  </div>
</template>

<script>
import DefaultButton from "@/components/buttonComponents/DefaultButton";

export default {
  components: {
    DefaultButton,
  },
};
</script>

<style lang="scss" scoped>
</style>