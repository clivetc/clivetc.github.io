<template>
  <div class="content-area col pt-4 pb-4">
    <div class="col hide-scroll">
      <baseheading level="3">Welcome to {{ course.course_code }}!</baseheading>
      <baseheading level="5">{{ course.course_description }}</baseheading>
      <div v-if="componentLoaded" class="">
        <editor-component @post="post"></editor-component>
      </div>
      <Posts :posts="posts"></Posts>
    </div>
  </div>
</template>

<script>
import Posts from "../../postsComponents/Posts";
import { mapGetters } from "vuex";
import EditorComponent from "../../formComponents/editorComponent.vue";
export default {
  components: {
    Posts,
    EditorComponent,
  },
  props: ["courseInfo"],

  mounted() {
    this.$store.dispatch("coursesStore/getCoursePosts", this.courseInfo[0].pk);
    console.log(this.courseInfo);
    this.$nextTick(() => {
      this.componentLoaded = true;
    });
  },
  computed: {
    ...mapGetters({
      posts: "coursesStore/getCoursePostsState",
    }),
  },
  data() {
    return {
      course: this.courseInfo[0].fields,

      componentLoaded: false,
    };
  },

  methods: {
    post(editorContent) {
      this.$store.dispatch("coursesStore/createPost", {
        course_id: this.courseInfo[0].pk,
        content: editorContent,
        post_type: "regular",
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.content-area {
  overflow: hidden;
  position: relative;
  padding-top: 1rem;
  padding-bottom: 1rem;
}

.hide-scroll {
  overflow-y: scroll;
  position: absolute;
  height: 100%;
  padding-top: 1rem;
  margin-bottom: 5rem;
}
</style>