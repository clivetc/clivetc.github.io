<template>
  <div class="mt-5">
    <AccordionList>
      <Accordion title="Courses">
        <AccordionItem v-for="course in courses" :key="course.course_code">
          <a :href="`/course/view/${course.id}`" class="">
            {{ course.course_code }}
          </a>
        </AccordionItem>
      </Accordion>
      <Accordion title="Assignments">
        <AccordionItem></AccordionItem>
      </Accordion>
    </AccordionList>
  </div>
</template>

<script>
import Accordion from "../../listComponents/Accordion";
import AccordionList from "../../listComponents/AccordionList";
import AccordionItem from "../../listComponents/AccordionItem";
import { mapGetters } from "vuex";

export default {
  components: {
    Accordion,
    AccordionList,
    AccordionItem,
  },
  computed: {
    ...mapGetters({
      courses: "coursesStore/getCoursesState",
    }),
  },
  beforeMount() {
    this.$store.dispatch("coursesStore/getUserSpecificCourses");
  },
};
</script>

<style lang="scss" scoped>
</style>