<template>
  <div class="mt-5 d-flex flex-column align-items-center">
    <div style="max-width: 200px">
      <default-button
        @clicked="toggleCreateCourse()"
        size="small"
        type="compliment"
        >Create a course</default-button
      >
      <dropdown-page :active="coursePageOpen" @closed="toggleCreateCourse()">
        <create-course-form></create-course-form>
      </dropdown-page>
    </div>
  </div>
</template>

<script>
import DefaultButton from "../../buttonComponents/DefaultButton.vue";
import CreateCourseForm from "../../forms/createCourseForm.vue";
import DropdownPage from "../../popupComponents/DropdownPage.vue";
export default {
  components: {
    DefaultButton,
    DropdownPage,
    CreateCourseForm,
  },
  data() {
    return {
      coursePageOpen: false,
    };
  },

  methods: {
    toggleCreateCourse() {
      this.coursePageOpen = !this.coursePageOpen;
    },
  },
};
</script>

<style lang="scss" scoped>
</style>
