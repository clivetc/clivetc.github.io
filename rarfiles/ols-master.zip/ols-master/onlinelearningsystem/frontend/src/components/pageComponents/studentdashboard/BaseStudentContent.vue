<template>
  <div class="pl-3 pr-3">
    <baseheading level="3"
      >Welcome {{ userProfile.first_name | capitalize }}!</baseheading
    >
    <Posts :posts="posts" context="dashboard"></Posts>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Posts from "../../postsComponents/Posts.vue";

export default {
  components: { Posts },
  mounted() {
    this.$store.dispatch("userStore/getRecentPosts");
  },
  computed: {
    ...mapGetters({
      posts: "userStore/getRecentPostsState",
    }),
  },
};
</script>

<style lang="scss" scoped>
</style>