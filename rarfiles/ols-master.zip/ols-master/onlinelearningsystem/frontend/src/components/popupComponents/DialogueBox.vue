<template>
  <div v-if="open" class="dialogue">
    <div @click="close" class="dialogue__background"></div>
    <div class="dialogue__box">
      <div class="dialogue__close-container">
        <IconButton
          @clicked="close"
          icon-style="fill: gray"
          name="Close"
        ></IconButton>
      </div>
      <div class="d-flex flex-column col">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton";

export default {
  components: {
    IconButton,
  },
  props: {
    open: {
      type: Boolean,
      default: true,
    },
  },
  methods: {
    close() {
      this.$emit("close");
    },
  },
};
</script>

<style lang="scss" scoped>
.dialogue {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
  height: 100vh;
  position: fixed;
  z-index: 300;
  top: 0;
  left: 0;

  &__box {
    z-index: 301;
    min-width: 300px;
    min-height: 300px;
    background: white;
    box-shadow: 0px 3px 5px 1px rgba(0, 0, 0, 0.33);
    padding: 1rem;
  }

  &__background {
    background: rgba(255, 255, 255, 0.4);
    position: absolute;
    width: 100%;
    height: 100%;
  }

  &__close-container {
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }
}
</style>