<template>
  <div
    v-if="active"
    class="dp__container dp__animate dp__animate--in"
    ref="dropdownpage"
  >
    <div class="d-flex w-100 justify-content-end align-items-center">
      <icon-button
        @clicked="close"
        size="xsmall"
        icon-style="fill: gray;"
        name="close"
      ></icon-button>
    </div>
    <div class="p-4">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton.vue";
export default {
  components: {
    IconButton,
  },
  props: ["active"],

  methods: {
    close() {
      this.$refs.dropdownpage.classList.add("dp__animate--out");
      setTimeout(() => {
        this.$emit("closed");
      }, 500);
    },
  },
};
</script>

<style lang="scss" scoped>
.dp {
  &__container {
    position: fixed;
    display: flex;
    flex-flow: column;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: white;
    z-index: 9999;
    padding: 1.5rem;
    overflow-y: scroll;
  }

  &__animate {
    animation-duration: 0.5s;
    animation-fill-mode: forwards;

    &--in {
      animation-name: in;
    }

    &--out {
      animation-name: out;
    }
  }
}

@keyframes in {
  from {
    top: -100%;
  }

  to {
    top: 0%;
  }
}

@keyframes out {
  from {
    top: 0%;
  }

  to {
    top: -100%;
  }
}
</style>