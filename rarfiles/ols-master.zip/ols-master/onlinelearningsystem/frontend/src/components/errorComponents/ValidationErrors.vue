<template>
  <div class="d-flex flex-column">
    <span class="col-12 error" v-for="error in errorsFinal" :key="error">
      <span
        class="d-flex align-items-center"
        v-for="errors in error"
        :key="errors"
      >
        <Important class="important_icon"></Important>
        {{ errors.message }}
      </span>
    </span>
  </div>
</template>

<script>
import Important from "../iconComponents/Important";
export default {
  name: "ValidationErrors",
  props: ["errors"],
  components: {
    Important,
  },
  data() {
    return {
      errorsFinal: "",
    };
  },
  mounted() {
    if (typeof this.errors === "string" && this.errors.length > 0) {
      this.errorsFinal = JSON.parse(this.errors);
    } else {
      this.errorsFinal = this.errors;
    }
    console.log(this.errorsFinal);
  },
};
</script>

<style lang="scss" scoped>
.important_icon {
  fill: white;
  margin-right: 1rem;
}

.error {
  margin-bottom: 1rem;
  border: 1px rgb(255, 116, 116) solid;
  background: rgb(255, 116, 116);
  color: white;
  border-radius: 5px;
  padding: 0.7rem 1rem;
  animation-name: errorAnimate;
  animation-duration: 1s;
}

@keyframes errorAnimate {
  0% {
    background: rgb(255, 116, 116);
  }

  50% {
    background: red;
  }

  100% {
    background: rgb(255, 116, 116);
  }
}
</style>