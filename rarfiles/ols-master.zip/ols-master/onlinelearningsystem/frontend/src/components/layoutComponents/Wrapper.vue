<template>
  <div
    class="wrapper"
    :style="{ maxWidth: getWrapperStyle(), padding: paddingVal }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: ["maxWidth", "padding"],
  data() {
    return {
      paddingVal: this.padding.length > 0 ? this.padding : "1rem",
      wrapperValue: "1440",
    };
  },
  methods: {
    getWrapperStyle() {
      return this.maxWidth == undefined
        ? this.wrapperValue + "px"
        : this.maxWidth + "px";
    },
  },
};
</script>

<style lang="scss" scoped>
.wrapper {
  margin: 0 auto;
  display: inherit;
  width: 100%;
  padding: 0rem 2rem;
}
</style>