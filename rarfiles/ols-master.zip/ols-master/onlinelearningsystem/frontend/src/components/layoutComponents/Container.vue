<template>
  <div :style="getPaddingAndMargin()" :class="getContainerClass()">
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    center: {
      type: Boolean,
      default: false,
    },
    left: {
      type: Boolean,
      default: true,
    },
    row: {
      type: Boolean,
      default: true,
    },
    padding: {
      type: String,
      default: "12",
    },
    margin: {
      type: String,
      default: "0",
    },
    width: {
      type: String,
      default: "",
    },
    space: {
      type: String,
      default: "unset",
    },
    card: {
      type: Boolean,
      default: false,
    },
    seperate: {
      type: Boolean,
      default: false,
    },
  },

  methods: {
    getContainerClass() {
      const { center, left, row, card, seperate } = this;
      var classList = "";

      if (center == true) classList = classList.concat("center ");

      if (row) {
        classList = classList.concat("base ");
        if (!left) classList = classList.concat("right-row ");
      } else {
        classList = classList.concat("base-column ");
        classList = classList.concat("column ");
        if (!left) classList = classList.concat("right-column ");
      }

      if (card) classList = classList.concat("card ");
      if (seperate) classList = classList.concat("seperate ");
      return classList;
    },

    getPaddingAndMargin() {
      return `padding:${this.padding}; margin:${this.margin}; width:${this.width};`;
    },
  },
};
</script>

<style lang="scss" scoped>
.base {
  display: flex;
  flex-flow: row;
  justify-content: flex-start;
  align-self: center;
}

.base-column {
  display: flex;
  flex-flow: row;
  align-items: flex-start;
  justify-content: center;
}

.right-row {
  justify-content: flex-end;
}

.right-column {
  align-items: flex-end;
}

.center {
  justify-content: center;
  align-items: center;
}

.column {
  flex-flow: column;
}

.card {
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
}

.seperate {
  justify-content: space-between !important;
}
</style>