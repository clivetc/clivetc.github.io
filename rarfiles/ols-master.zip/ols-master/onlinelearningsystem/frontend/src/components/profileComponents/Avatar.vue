<template>
  <div :class="`avatar avatar--${size}`"></div>
</template>

<script>
export default {
  props: {
    size: {
      type: String,
      default: "small",
    },
  },
};
</script>

<style lang="scss" scoped>
.avatar {
  background: lightgray;
  margin: 0rem 1rem;
  border-radius: 50%;
  &--xsmall {
    width: 24px;
    height: 24px;
  }

  &--small {
    width: 36px;
    height: 36px;
  }
}
</style>