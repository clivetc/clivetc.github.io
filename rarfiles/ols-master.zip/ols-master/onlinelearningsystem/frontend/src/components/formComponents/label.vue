<template>
  <div class="avoid-clicks">{{ label }}</div>
</template>

<script>
export default {
  props: ["label"],
};
</script>

<style lang="scss" scoped>
.avoid-clicks {
  pointer-events: none;
  z-index: 99;
}
</style>