<template>
  <base-dropzone
    :url="url"
    :existing-files-url="existingFilesUrl"
    :remove-file-link="removeFileLink"
    :options="options"
  ></base-dropzone>
</template>

<script>
import BaseDropzone from "./BaseDropzone.vue";
export default {
  components: {
    BaseDropzone,
  },
  props: ["url", "existingFilesUrl", "removeFileLink"],
  data() {
    return {
      options: {
        addRemoveLinks: true,
        clickable: true,
        dropEnabled: true,
      },
    };
  },
};
</script>

<style lang="scss">
</style>