<template>
  <div class="d-flex flex-column my-3">
    <ckeditor v-model="editorData" :config="editorConfig"></ckeditor>
    <div class="mt-3">
      <default-button @clicked="post" size="small" type="compliment"
        >Create Post</default-button
      >
    </div>
  </div>
</template>

<script>
import DefaultButton from "../buttonComponents/DefaultButton.vue";
export default {
  components: { DefaultButton },
  data() {
    return {
      editorData: "",
      editorConfig: {
        filebrowserBrowseUrl: "/ckfinder/ckfinder.html",
        filebrowserUploadUrl: "/api/posts/upload/",
        extraPlugins: "uploadimage",
        uploadUrl: "/api/posts/upload/",
        fileTools_requestHeaders: {
          "X-CSRFToken": window.csrftoken,
        },
      },
    };
  },
  methods: {
    post() {
      this.$emit("post", this.editorData);
    },
  },
};
</script>

<style lang="scss" scoped>
</style>