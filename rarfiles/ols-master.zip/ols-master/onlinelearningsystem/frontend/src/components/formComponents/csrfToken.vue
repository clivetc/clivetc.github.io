<template>
  <input type="hidden" :value="csrfToken" name="csrfmiddlewaretoken" />
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>