<template>
  <form class="dropzone" method="post" ref="dropzone" :action="url">
    <csrf-token></csrf-token>
  </form>
</template>

<script>
import CsrfToken from "./csrfToken.vue";
import Dropzone from "@/vendor/dropzone-5.7.0/index";
import axios from "../../httpClient/axios";
export default {
  components: {
    CsrfToken,
  },
  props: {
    url: {
      type: String,
      default: "",
    },
    existingFilesUrl: {
      type: String,
      default: "",
    },
    removeFileLink: {
      type: String,
      default: "",
    },
    options: {
      type: Object,
      default: function () {
        return {
          addRemoveLinks: false,
          clickable: false,
          dropEnabled: false,
        };
      },
    },
  },
  async mounted() {
    let self = this;
    let existingfiles = await axios.get(this.existingFilesUrl);
    let addedFiles = [];
    console.log(existingfiles);
    let dz = new Dropzone(this.$refs.dropzone, {
      addRemoveLinks: this.options.addRemoveLinks,
      clickable: this.options.clickable,
      previewTemplate:
        '<div class="dz-preview dz-file-preview">\n  <div class="dz-image"><img data-dz-thumbnail /></div>\n  <a class="dz-path" data-dz-path target="_blank"><div class="dz-details">\n    <div class="dz-size"><span data-dz-size></span></div>\n    <div class="dz-filename"><span data-dz-name></span></div>\n  </div>\n </a> <div class="dz-progress"><span class="dz-upload" data-dz-uploadprogress></span></div>\n  <div class="dz-error-message"><span data-dz-errormessage></span></div>\n  <div class="dz-success-mark">\n    <svg width="54px" height="54px" viewBox="0 0 54 54" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n      <title>Check</title>\n      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\n        <path d="M23.5,31.8431458 L17.5852419,25.9283877 C16.0248253,24.3679711 13.4910294,24.366835 11.9289322,25.9289322 C10.3700136,27.4878508 10.3665912,30.0234455 11.9283877,31.5852419 L20.4147581,40.0716123 C20.5133999,40.1702541 20.6159315,40.2626649 20.7218615,40.3488435 C22.2835669,41.8725651 24.794234,41.8626202 26.3461564,40.3106978 L43.3106978,23.3461564 C44.8771021,21.7797521 44.8758057,19.2483887 43.3137085,17.6862915 C41.7547899,16.1273729 39.2176035,16.1255422 37.6538436,17.6893022 L23.5,31.8431458 Z M27,53 C41.3594035,53 53,41.3594035 53,27 C53,12.6405965 41.3594035,1 27,1 C12.6405965,1 1,12.6405965 1,27 C1,41.3594035 12.6405965,53 27,53 Z" stroke-opacity="0.198794158" stroke="#747474" fill-opacity="0.816519475" fill="#FFFFFF"></path>\n      </g>\n    </svg>\n  </div>\n  <div class="dz-error-mark">\n    <svg width="54px" height="54px" viewBox="0 0 54 54" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n      <title>Error</title>\n      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\n        <g stroke="#747474" stroke-opacity="0.198794158" fill="#FFFFFF" fill-opacity="0.816519475">\n          <path d="M32.6568542,29 L38.3106978,23.3461564 C39.8771021,21.7797521 39.8758057,19.2483887 38.3137085,17.6862915 C36.7547899,16.1273729 34.2176035,16.1255422 32.6538436,17.6893022 L27,23.3431458 L21.3461564,17.6893022 C19.7823965,16.1255422 17.2452101,16.1273729 15.6862915,17.6862915 C14.1241943,19.2483887 14.1228979,21.7797521 15.6893022,23.3461564 L21.3431458,29 L15.6893022,34.6538436 C14.1228979,36.2202479 14.1241943,38.7516113 15.6862915,40.3137085 C17.2452101,41.8726271 19.7823965,41.8744578 21.3461564,40.3106978 L27,34.6568542 L32.6538436,40.3106978 C34.2176035,41.8744578 36.7547899,41.8726271 38.3137085,40.3137085 C39.8758057,38.7516113 39.8771021,36.2202479 38.3106978,34.6538436 L32.6568542,29 Z M27,53 C41.3594035,53 53,41.3594035 53,27 C53,12.6405965 41.3594035,1 27,1 C12.6405965,1 1,12.6405965 1,27 C1,41.3594035 12.6405965,53 27,53 Z"></path>\n        </g>\n      </g>\n    </svg>\n  </div>\n</div>',
      dictDefaultMessage: self.options.dropEnabled
        ? "Drop a file to upload it"
        : "Drop disabled",
      init: function () {
        if (existingfiles.data) {
          existingfiles.data.assignment_submitted_files.forEach((file) => {
            console.log(file);
            var mockFile = {
              name: file.title,
              size: file.size,
              type: self.getMimeType(file.type),
              path: "/static/" + file.path,
              file_id: file.id,
            };

            this.files.push(mockFile); // add to files array
            this.options.addedfile.call(this, mockFile);
            this.options.thumbnail.call(this, mockFile, "/static/" + file.path);

            this.emit("complete", mockFile);
            this.on("addedfile", (file) => {
              addedFiles.push(file);
            });
          });
        }

        if (!self.options.dropEnabled) {
          console.log("not enabled");
          this.drop = function () {};
        }
      },
    });

    this.addLinkToFiles(dz.files);

    dz.on("removedfile", (file) => {
      this.$store.dispatch("assignmentStore/removeFile", {
        file: file,
        link: this.removeFileLink,
      });
    });

    dz.on("success", (file, response) => {
      file.path = "/static/" + response.path;
      this.addLinkToSingleFile(file);
    });
  },

  methods: {
    getMimeType(fileType) {
      switch (fileType) {
        case ".jpg":
          return "image/jpeg";
        case ".png":
          return "image/png";
        case ".pdf":
          return "application/pdf";
        case ".zip":
          return "application/zip";
        default:
          break;
      }
    },

    addLinkToFiles(files) {
      let $ = window.$;
      files.forEach((file) => {
        let element = $(file.previewElement);
        let linkEl = $(element.find(".dz-path")[0]);
        linkEl.attr("href", file.path);
      });
    },

    addLinkToSingleFile(file) {
      let $ = window.$;
      let element = $(file.previewElement);
      let linkEl = $(element.find(".dz-path")[0]);
      linkEl.attr("href", file.path);
    },
  },
};
</script>

<style lang="scss">
/*
 * The MIT License
 * Copyright (c) 2012 Matias Meno <m@tias.me>
 */

// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal in
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
// of the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

.dropzone,
.dropzone * {
  box-sizing: border-box;
}
.dropzone {
  position: relative;

  .dz-preview {
    position: relative;
    display: inline-block;
    width: 120px;
    margin: 0.5em;

    .dz-progress {
      display: block;
      height: 15px;
      border: 1px solid #aaa;
      .dz-upload {
        display: block;
        height: 100%;
        width: 0;
        background: green;
      }
    }

    .dz-error-message {
      color: red;
      display: none;
    }
    &.dz-error {
      .dz-error-message,
      .dz-error-mark {
        display: block;
      }
    }
    &.dz-success {
      .dz-success-mark {
        display: block;
      }
    }

    .dz-error-mark,
    .dz-success-mark {
      position: absolute;
      display: none;
      left: 30px;
      top: 30px;
      width: 54px;
      height: 58px;
      left: 50%;
      margin-left: -(54px/2);
    }
  }
}

/*
 * The MIT License
 * Copyright (c) 2012 Matias Meno <m@tias.me>
 */

// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal in
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
// of the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

@mixin keyframes($name) {
  @-webkit-keyframes #{$name} {
    @content;
  }
  @-moz-keyframes #{$name} {
    @content;
  }
  @keyframes #{$name} {
    @content;
  }
}

@mixin prefix($map, $vendors: webkit moz ms o) {
  @each $prop, $value in $map {
    @if $vendors {
      @each $vendor in $vendors {
        #{"-" + $vendor + "-" + $prop}: #{$value};
      }
    }
    // Dump regular property anyway
    #{$prop}: #{$value};
  }
}

@include keyframes(passing-through) {
  0% {
    opacity: 0;
    @include prefix(
      (
        transform: translateY(40px),
      )
    );
  }

  30%,
  70% {
    opacity: 1;
    @include prefix(
      (
        transform: translateY(0px),
      )
    );
  }

  100% {
    opacity: 0;
    @include prefix(
      (
        transform: translateY(-40px),
      )
    );
  }
}

@include keyframes(slide-in) {
  0% {
    opacity: 0;
    @include prefix(
      (
        transform: translateY(40px),
      )
    );
  }

  30% {
    opacity: 1;
    @include prefix(
      (
        transform: translateY(0px),
      )
    );
  }
}

@include keyframes(pulse) {
  0% {
    @include prefix(
      (
        transform: scale(1),
      )
    );
  }
  10% {
    @include prefix(
      (
        transform: scale(1.1),
      )
    );
  }
  20% {
    @include prefix(
      (
        transform: scale(1),
      )
    );
  }
}

.dropzone,
.dropzone * {
  box-sizing: border-box;
}
.dropzone {
  $image-size: 120px;

  $image-border-radius: 20px;

  &.dz-clickable {
    cursor: pointer;

    * {
      cursor: default;
    }
    .dz-message {
      &,
      * {
        cursor: pointer;
      }
    }
  }

  min-height: 150px;

  border: 2px dashed #0087f7;
  border-radius: 5px;
  background: white;

  padding: 20px 20px;

  &.dz-started {
    .dz-message {
      display: none;
    }
  }

  &.dz-drag-hover {
    border-style: solid;
    .dz-message {
      opacity: 0.5;
    }
  }
  .dz-message {
    text-align: center;
    margin: 2em 0;

    .dz-button {
      background: none;
      color: inherit;
      border: none;
      padding: 0;
      font: inherit;
      cursor: pointer;
      outline: inherit;
    }
  }

  .dz-preview {
    position: relative;
    display: inline-block;

    vertical-align: top;

    margin: 16px;
    min-height: 100px;

    &:hover {
      // Making sure that always the hovered preview element is on top
      z-index: 1000;
      .dz-details {
        opacity: 1;
      }
    }

    &.dz-file-preview {
      .dz-image {
        border-radius: $image-border-radius;
        background: #999;
        background: linear-gradient(to bottom, #eee, #ddd);
      }

      .dz-details {
        opacity: 1;
      }
    }

    &.dz-image-preview {
      background: white;
      .dz-details {
        @include prefix(
          (
            transition: opacity 0.2s linear,
          )
        );
      }
    }

    .dz-remove {
      font-size: 14px;
      text-align: center;
      display: block;
      cursor: pointer;
      border: none;
      &:hover {
        text-decoration: underline;
      }
    }

    &:hover .dz-details {
      opacity: 1;
    }
    .dz-details {
      $background-color: #444;

      z-index: 20;

      position: absolute;
      top: 0;
      left: 0;

      opacity: 0;

      font-size: 13px;
      min-width: 100%;
      max-width: 100%;
      padding: 2em 1em;
      text-align: center;
      color: rgba(0, 0, 0, 0.9);

      $width: 120px;

      line-height: 150%;

      .dz-size {
        margin-bottom: 1em;
        font-size: 16px;
      }

      .dz-filename {
        white-space: nowrap;

        &:hover {
          span {
            border: 1px solid rgba(200, 200, 200, 0.8);
            background-color: rgba(255, 255, 255, 0.8);
          }
        }
        &:not(:hover) {
          span {
            border: 1px solid transparent;
          }
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }

      .dz-filename,
      .dz-size {
        span {
          background-color: rgba(255, 255, 255, 0.4);
          padding: 0 0.4em;
          border-radius: 3px;
        }
      }
    }

    &:hover {
      .dz-image {
        // opacity: 0.8;
        img {
          @include prefix(
            (
              transform: scale(1.05, 1.05),
            )
          ); // Getting rid of that white bleed-in
          @include prefix(
            (
              filter: blur(8px),
            ),
            webkit
          ); // Getting rid of that white bleed-in
        }
      }
    }
    .dz-image {
      border-radius: $image-border-radius;
      overflow: hidden;
      width: $image-size;
      height: $image-size;
      position: relative;
      display: block;
      z-index: 10;

      img {
        display: block;
      }
    }

    &.dz-success {
      .dz-success-mark {
        @include prefix(
          (
            animation: passing-through 3s cubic-bezier(0.77, 0, 0.175, 1),
          )
        );
      }
    }
    &.dz-error {
      .dz-error-mark {
        opacity: 1;
        @include prefix(
          (
            animation: slide-in 3s cubic-bezier(0.77, 0, 0.175, 1),
          )
        );
      }
    }

    .dz-success-mark,
    .dz-error-mark {
      $image-height: 54px;
      $image-width: 54px;

      pointer-events: none;

      opacity: 0;
      z-index: 500;

      position: absolute;
      display: block;
      top: 50%;
      left: 50%;
      margin-left: -($image-width/2);
      margin-top: -($image-height/2);

      svg {
        display: block;
        width: $image-width;
        height: $image-height;
      }
    }

    &.dz-processing .dz-progress {
      opacity: 1;
      @include prefix(
        (
          transition: all 0.2s linear,
        )
      );
    }
    &.dz-complete .dz-progress {
      opacity: 0;
      @include prefix(
        (
          transition: opacity 0.4s ease-in,
        )
      );
    }

    &:not(.dz-processing) {
      .dz-progress {
        @include prefix(
          (
            animation: pulse 6s ease infinite,
          )
        );
      }
    }
    .dz-progress {
      opacity: 1;
      z-index: 1000;

      pointer-events: none;
      position: absolute;
      height: 16px;
      left: 50%;
      top: 50%;
      margin-top: -8px;

      width: 80px;
      margin-left: -40px;

      // border: 2px solid #333;
      background: rgba(255, 255, 255, 0.9);

      // Fix for chrome bug: https://code.google.com/p/chromium/issues/detail?id=157218
      -webkit-transform: scale(1);

      border-radius: 8px;

      overflow: hidden;

      .dz-upload {
        background: #333;
        background: linear-gradient(to bottom, #666, #444);
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        width: 0;
        @include prefix(
          (
            transition: width 300ms ease-in-out,
          )
        );
      }
    }

    &.dz-error {
      .dz-error-message {
        display: block;
      }
      &:hover .dz-error-message {
        opacity: 1;
        pointer-events: auto;
      }
    }

    .dz-error-message {
      $width: $image-size + 20px;
      $color: rgb(190, 38, 38);

      pointer-events: none;
      z-index: 1000;
      position: absolute;
      display: block;
      display: none;
      opacity: 0;
      @include prefix(
        (
          transition: opacity 0.3s ease,
        )
      );
      border-radius: 8px;
      font-size: 13px;
      top: $image-size + 10px;
      left: -10px;
      width: $width;
      background: $color;
      background: linear-gradient(to bottom, $color, darken($color, 5%));
      padding: 0.5em 1.2em;
      color: white;

      // The triangle pointing up
      &:after {
        content: "";
        position: absolute;
        top: -6px;
        left: $width / 2 - 6px;
        width: 0;
        height: 0;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        border-bottom: 6px solid $color;
      }
    }
  }
}
</style>