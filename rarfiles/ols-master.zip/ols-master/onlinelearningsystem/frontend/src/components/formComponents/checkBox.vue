<template>
  <div class="d-flex align-items-center">
    <input v-model="boxChecked" type="hidden" :name="name" />
    <div class="mr-3 box-container" @click="checkTheBox">
      <Box class="checkbox"></Box>
      <Tick class="tick" :class="{ ticked: boxChecked }"></Tick>
    </div>
    <span><slot></slot></span>
  </div>
</template>

<script>
import Box from "../iconComponents/Checkbox";
import Tick from "../iconComponents/Tick";
export default {
  props: ["name", "text"],
  components: {
    Box,
    Tick,
  },
  data() {
    return {
      boxChecked: false,
    };
  },
  methods: {
    checkTheBox() {
      this.boxChecked = !this.boxChecked;
    },
  },
};
</script>

<style lang="scss" scoped>
.box-container {
  position: relative;
  cursor: pointer;
}
.checkbox {
  outline: none;
  width: 1.5rem;
  height: 1.5rem;
}

.tick {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 60%;
  height: 60%;
  opacity: 0;
  transition: opacity 0.1s ease-in-out;
}

.ticked {
  opacity: 1;
}
</style>