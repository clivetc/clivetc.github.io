<template>
  <div class="input__container">
    <div class="input">
      <Label class="label" :class="labelClass()" :label="label"></Label>
      <input type="hidden" v-model="selectedValue" :name="name" />

      <div
        @click="openMenu"
        class="input__field row align-items-center no-gutters"
      >
        <span class="col-10">{{ selectedValue }}</span>
        <div class="col-2">
          <IconButton
            color="black"
            size="xsmall"
            name="LeftArrow"
            :class="{ rotate: menuOpen }"
            class="rotate--before"
          ></IconButton>
        </div>
        <Container
          style="background: white"
          :card="true"
          width="100%"
          class="dropdown--before dropdown"
          v-if="menuOpen"
          padding="0"
        >
          <span
            @click="setSelect(option.value, option.name)"
            v-for="option in options"
            :key="option"
            class="dropdown__item"
            >{{ option.name }}
          </span>
        </Container>
      </div>
    </div>
  </div>
</template>

<script>
import Label from "./label";
import IconButton from "../buttonComponents/IconButton";
import Container from "../layoutComponents/Container";
export default {
  components: {
    Label,
    IconButton,
    Container,
  },
  props: ["name", "options", "label"],
  data() {
    return {
      text: "",
      selectedValue: "",
      menuOpen: false,
    };
  },

  methods: {
    labelClass() {
      const { selectedValue } = this;

      if (selectedValue.length > 0) {
        return "label--open";
      } else {
        return "label--closed";
      }
    },
    setSelect(value, name) {
      this.selectedValue = name;
    },
    openMenu() {
      this.menuOpen = !this.menuOpen;
    },
  },
};
</script>

<style lang="scss" scoped>
.dropdown {
  transition: opacity 0.1s ease-in-out;
  position: absolute;
  top: 100%;
  z-index: 100;
  left: 0;
  display: flex;
  flex-flow: column;

  &__item {
    padding: 1rem;

    &:hover {
      background: rgba($color: #000000, $alpha: 0.3);
    }
  }

  animation-name: dropdownAppear;
  animation-duration: 0.2s;
}

.input {
  position: relative;
  &__container {
    width: 100%;
    margin-bottom: 1rem;
  }

  &__field {
    border: none;
    padding: 1rem;
    box-shadow: 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
    border-radius: 8px;
    width: 100%;
    min-width: 160px;
    outline: none;
    cursor: pointer;
    &:focus {
      border: 2px $primaryColor solid;
    }

    &:active {
      border: 2px $primaryColor solid;
    }
  }

  .rotate {
    &--before {
      transition: transform 0.1s ease-in-out;
    }
    transform: rotate(-90deg);
    transition: transform 0.1s ease-in-out;
  }

  .label {
    position: absolute;
    transition: all 0.2s ease-in-out;
    &--closed {
      top: 50%;
      left: 2rem;
      transform: translateY(-50%);
      color: rgba($color: #000000, $alpha: 0.4);
      font-size: 1rem;
    }

    &--open {
      top: -12px;
      left: 1.5rem;
      background: white;
      padding: 0.3rem;
      color: $primaryColor;
      font-size: 0.8rem;
    }
  }
}

@keyframes dropdownAppear {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}
</style>