<template>
  <div class="input__container">
    <div class="input">
      <Label class="label" :class="labelClass()" :label="label"></Label>
      <input
        @change="emitChange"
        class="input__field"
        :type="type"
        :name="name"
        v-model="text"
      />
    </div>
  </div>
</template>

<script>
import Label from "./label";
export default {
  components: {
    Label,
  },
  props: ["name", "type", "label"],
  data() {
    return {
      text: "",
    };
  },
  mounted() {
    this.labelClass();
  },
  methods: {
    labelClass() {
      const { text } = this;

      if (text.length > 0) {
        return "label--open";
      } else {
        return "label--closed";
      }
    },

    emitChange() {
      this.$emit("changed", this.text);
    },
  },
};
</script>

<style lang="scss" scoped>
.input {
  position: relative;
  &__container {
    width: 100%;
    margin-bottom: 1rem;
  }

  &__field {
    border: none;
    padding: 1em;
    box-shadow: 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
    border-radius: 8px;
    width: 100%;
    min-width: 220px;
    outline: none;
    background: white !important;
    &:focus {
      border: 2px $primaryColor solid;
    }
  }

  .label {
    position: absolute;
    transition: all 0.2s ease-in-out;
    &--closed {
      top: 50%;
      left: 2rem;
      transform: translateY(-50%);
      color: rgba($color: #000000, $alpha: 0.4);
      font-size: 1rem;
    }

    &--open {
      top: -12px;
      left: 1.5rem;
      background: white;
      padding: 0.3rem;
      color: $primaryColor;
      font-size: 0.8rem;
    }
  }
}
</style>