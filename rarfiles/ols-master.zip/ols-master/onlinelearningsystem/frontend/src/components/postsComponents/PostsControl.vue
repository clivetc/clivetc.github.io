<template>
  <div class="posts-control__container">
    <div class="posts-control__label">Sort Posts By</div>
    <div>
      <select-input
        style="padding: 0rem"
        label="Sort"
        :options="selectOptions()"
      ></select-input>
    </div>
  </div>
</template>

<script>
import selectInput from "../formComponents/selectInput.vue";
export default {
  components: { selectInput },
  methods: {
    selectOptions() {
      return [
        { name: "New", value: "new" },

        { name: "Popular", value: "popular" },
      ];
    },
  },
};
</script>

<style lang="scss" scoped>
.posts-control {
  &__container {
    display: flex;
    width: 100%;
    justify-content: space-between;
    align-items: center;
  }
}
</style>