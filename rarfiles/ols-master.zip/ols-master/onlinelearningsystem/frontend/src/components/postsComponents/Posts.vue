<template>
  <div class="posts__container">
    <div class="posts__controls">
      <posts-control></posts-control>
    </div>
    <Post
      :context="context"
      v-for="post in posts"
      :key="post.id"
      :post="post"
    ></Post>
  </div>
</template>

<script>
import Post from "./Post";
import PostsControl from "./PostsControl.vue";
export default {
  props: ["posts", "context"],
  components: {
    Post,
    PostsControl,
  },
};
</script>

<style lang="scss" scoped>
.posts {
  &__container {
    display: flex;
    flex-flow: column;
    align-items: center;
    padding-bottom: 3rem;
  }

  &__controls {
    margin: 1rem 0rem;
    width: 100%;
  }
}
</style>