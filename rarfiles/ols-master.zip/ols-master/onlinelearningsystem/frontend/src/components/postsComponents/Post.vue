<template>
  <div class="post__container">
    <div class="post__meta">
      <div class="post__avatar-container">
        <div class="post__avatar"></div>
      </div>
      <div class="post__info-container">
        <div class="post__owner">
          {{ post.user.userprofile.first_name }}
          {{ post.user.userprofile.last_name }}
          <span v-if="getContext() == 'dashboard'" class="post__seperator"
            >-</span
          ><span v-if="getContext() == 'dashboard'" class="post__class">{{
            post.course.course_code
          }}</span>
        </div>
        <div class="post__date">{{ getTimeFromNow(post.updated) }}</div>
      </div>
    </div>
    <div v-html="post.content" class="post__content"></div>
    <div class="post__attachments">
      <link-button
        :to="`/course/view/${5}/assignments/${post.resource_id}`"
        type="compliment"
        v-if="post.resource_id && post.post_type == 'ASSIGNMENT'"
      >
        Go to assignment
      </link-button>
    </div>
    <div class="post__actions">
      <icon-button name="Cog" color="black" size="small"></icon-button>
      <icon-button name="Cog" color="black" size="small"></icon-button>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton.vue";
import relativeTime from "dayjs/plugin/relativeTime";
import utc from "dayjs/plugin/utc";
import dayjs from "dayjs";
import LinkButton from "../buttonComponents/LinkButton.vue";

export default {
  props: ["post", "context"],
  mounted() {
    console.log(this.post);
  },
  components: {
    IconButton,
    LinkButton,
  },
  methods: {
    getTimeFromNow(time) {
      dayjs.extend(relativeTime);
      dayjs.extend(utc);
      return dayjs().to(dayjs(time).utc());
    },

    getContext() {
      return this.context;
    },
  },
};
</script>

<style lang="scss">
.post {
  &__container {
    max-width: 650px;
    min-width: 300px;
    width: 100%;
    box-shadow: 0px 0px 5px 1px lightgray;
    background: white;
    display: flex;
    flex-flow: column;
    align-items: center;
    padding: 1rem;
    margin-bottom: 2rem;
  }

  &__meta {
    display: flex;
    align-items: center;
    width: 100%;
  }

  &__avatar {
    &-container {
      width: 10%;
      min-width: 48px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-right: 1rem;
    }

    background: gray;
    width: 48px;
    height: 48px;
    border-radius: 50%;
  }

  &__info-container {
    width: 90%;
  }

  &__owner {
  }

  &__date {
    font-size: 0.8rem;
    color: gray;
  }

  &__content {
    padding-top: 1rem;
    text-align: left;
    width: 100%;

    img {
      width: 100% !important;
      height: initial !important;
    }
  }

  &__attachments {
    margin-top: 1rem;
  }

  &__actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    width: 100%;
    padding-top: 1rem;
  }

  &__class {
  }

  &__seperator {
    margin: 0rem 0.4rem;
  }
}
</style>