<template>
  <span>{{ determineMode(time) }}</span>
</template>

<script>
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import utc from "dayjs/plugin/utc";

export default {
  props: ["time", "dueMode", "dueMessagesConfig"],
  methods: {
    mounted() {
      dayjs.extend(relativeTime);
      dayjs.extend(utc);
    },
    determineMode(time) {
      if (this.dueMode) {
        return this.getDueTime(time);
      }
      return this.getTime(time);
    },
    getTime(time) {
      dayjs.extend(relativeTime);
      dayjs.extend(utc);
      return dayjs().to(dayjs(time).utc());
    },

    getDueTime(time) {
      dayjs.extend(relativeTime);
      dayjs.extend(utc);
      let config = this.dueMessagesConfig;
      let now = dayjs();
      let dueDate = dayjs(time);
      let isBefore = dueDate.isAfter(now);

      if (!isBefore) {
        return config.past_due + now.to(time, true);
      }

      return config.future_due + now.to(time, true);
    },
  },
};
</script>

<style lang="scss" scoped>
</style>