<template>
  <div :style="{ width: width }">
    <svg
      v-if="!invert"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 162.35 67.08"
    >
      <title>Asset 1</title>
      <g id="Layer_2" data-name="Layer 2">
        <g id="Layer_1-2" data-name="Layer 1">
          <text class="cls-1" transform="translate(45.44 54.07)">OLS</text>
          <polygon
            points="103.18 9.24 102.36 11.86 112.09 20.2 124.8 18.83 125.65 16.12 112.83 17.51 103.18 9.24"
          />
          <polygon
            points="135.86 14.25 113.08 16.71 95.68 1.8 118.26 0 135.86 14.25"
          />
          <line class="cls-2" x1="129.96" y1="12.81" x2="129.96" y2="27.59" />
          <path
            d="M130.33,29.31a.76.76,0,0,1,0,.16h-.68a.78.78,0,0,1,0-.16.41.41,0,0,1,0-.16h.68A.41.41,0,0,1,130.33,29.31Z"
          />
          <path d="M129.35,30.63c.1-.61.34-1,.61-1s.52.42.61,1Z" />
          <circle cx="129.96" cy="28.54" r="0.51" />
        </g>
      </g>
    </svg>
    <svg v-else xmlns="http://www.w3.org/2000/svg" viewBox="0 0 162.35 67.08">
      <title>Asset 2</title>
      <g id="Layer_2" data-name="Layer 2">
        <g id="Layer_1-2" data-name="Layer 1">
          <text class="cls-1-w" transform="translate(45.44 54.07)">OLS</text>
          <polygon
            class="cls-2-w"
            points="103.18 9.24 102.36 11.86 112.09 20.2 124.8 18.83 125.65 16.12 112.83 17.51 103.18 9.24"
          />
          <polygon
            class="cls-2-w"
            points="135.86 14.25 113.08 16.71 95.68 1.8 118.26 0 135.86 14.25"
          />
          <line class="cls-3-w" x1="129.96" y1="12.81" x2="129.96" y2="27.59" />
          <path
            class="cls-2-w"
            d="M130.33,29.31a.76.76,0,0,1,0,.16h-.68a.78.78,0,0,1,0-.16.41.41,0,0,1,0-.16h.68A.41.41,0,0,1,130.33,29.31Z"
          />
          <path
            class="cls-2-w"
            d="M129.35,30.63c.1-.61.34-1,.61-1s.52.42.61,1Z"
          />
          <circle class="cls-2-w" cx="129.96" cy="28.54" r="0.51" />
        </g>
      </g>
    </svg>
  </div>
</template>

<script>
export default {
  props: {
    invert: {
      type: Boolean,
      default: true,
    },
    width: {
      type: String,
      default: "unset",
    },
  },
};
</script>

<style lang="scss" scoped>
.cls-1 {
  font-size: 48px;
  font-family: Roboto-Regular, Roboto;
  letter-spacing: -0.16em;
}
.cls-2 {
  stroke: #000;
  stroke-linecap: round;
  stroke-miterlimit: 10;
  stroke-width: 0.5px;
}

.cls-1-w {
  font-size: 48px;
  font-family: Roboto-Regular, Roboto;
  letter-spacing: -0.16em;
}
.cls-1-w,
.cls-2-w,
.cls-3-w {
  fill: #fff;
}
.cls-3-w {
  stroke: #fff;
  stroke-linecap: round;
  stroke-miterlimit: 10;
  stroke-width: 0.5px;
}
</style>