<template>
  <div>This is my footer</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>