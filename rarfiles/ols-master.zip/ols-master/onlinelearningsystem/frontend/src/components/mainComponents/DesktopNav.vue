<template>
  <Container padding="0" margin="0">
    <Nav :items="getNavItems()"></Nav>
  </Container>
</template>

<script>
import Container from "@/components/layoutComponents/Container";
import Nav from "@/components/listComponents/Nav";
export default {
  components: {
    Container,
    Nav,
  },

  methods: {
    getNavItems() {
      return [
        {
          name: "Home",
          link: "/",
          children: [
            {
              name: "Blog",
              link: "/blog",
              children: [
                {
                  name: "Kek",
                  link: "/kek",
                },
                {
                  name: "Kek",
                  link: "/kek",
                },
                {
                  name: "Kek",
                  link: "/kek",
                },
              ],
            },
          ],
        },

        {
          name: "About",
          link: "/about",
        },
        {
          name: "Contact Us",
          link: "/contact",
        },
      ];
    },
  },
};
</script>

<style lang="scss" scoped>
</style>