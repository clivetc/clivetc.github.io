<template>
  <div>
    <Drawer @close-menu="emitClose" close-icon-name="Close">
      <div class="auth-area">
        <div class="d-flex flex-column align-items-center" v-if="isAuth">
          <div class="auth__avatar"></div>
          <div class="auth__username">
            {{ userProfile.first_name }} {{ userProfile.last_name }}
          </div>
          <div class="d-flex w-100 justify-content-end align-items-center mt-4">
            <div>
              <IconButton
                @clicked="goToDashboard()"
                color="black"
                name="User"
              ></IconButton>
            </div>
            <div>
              <OptionMenu menuIcon="Options" iconColor="black">
                <OptionMenuItem to="/user/dashboard">Dashboard</OptionMenuItem>
                <OptionMenuItem>Courses</OptionMenuItem>
                <OptionMenuItem>Settings</OptionMenuItem>
              </OptionMenu>
            </div>
          </div>
        </div>
        <div class="d-flex align-items-center justify-content-around" v-else>
          <LinkButton
            class="col-4"
            :shadow="false"
            to="/user/login"
            size="small"
            type="compliment"
            >login</LinkButton
          >
          <LinkButton
            class="col-4"
            :shadow="false"
            to="/user/register"
            size="small"
            type="compliment"
            >register</LinkButton
          >
        </div>
      </div>
      <DrawerItem>Home</DrawerItem>
      <DrawerItem>About</DrawerItem>
      <DrawerItem>Contact</DrawerItem>
    </Drawer>
  </div>
</template>

<script>
import Drawer from "../listComponents/Drawer";
import DrawerItem from "../listComponents/DrawerItem";
import LinkButton from "../buttonComponents/LinkButton";
import OptionMenu from "../listComponents/OptionMenu";
import OptionMenuItem from "../listComponents/OptionMenuItem";
import IconButton from "../buttonComponents/IconButton";
export default {
  components: {
    Drawer,
    DrawerItem,
    LinkButton,
    OptionMenu,
    OptionMenuItem,
    IconButton,
  },
  methods: {
    emitClose() {
      console.log("mobile menu received event");
      this.$emit("close-menu");
    },
    goToDashboard() {
      window.location.href = "/user/dashboard";
    },
  },
};
</script>

<style lang="scss" scoped>
.auth-area {
  border-bottom: 1px solid rgba($color: #000000, $alpha: 0.16);
  padding: 0rem 1rem 1rem 1rem;
}

.auth {
  &__avatar {
    width: 64px;
    height: 64px;
    background: lightgray;
    display: block;
    border-radius: 50%;
    margin-bottom: 1rem;
  }
}
</style>