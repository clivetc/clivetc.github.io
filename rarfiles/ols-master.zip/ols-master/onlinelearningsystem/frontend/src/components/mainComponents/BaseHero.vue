<template>
  <Container>
    <Wrapper padding="0rem">
      <Container width="100%" :row="false" :center="true">
        <baseheading level="3">Online Learning System</baseheading>
        <baseheading level="4">Online Learning System</baseheading>
        <Container width="300px">
          <DefaultButton type="compliment">JOIN TODAY</DefaultButton>
        </Container>
      </Container>
    </Wrapper>
  </Container>
</template>

<script>
import Container from "../layoutComponents/Container";
import DefaultButton from "../buttonComponents/DefaultButton";
export default {
  components: {
    Container,
    DefaultButton,
  },
};
</script>

<style lang="scss" scoped>
</style>