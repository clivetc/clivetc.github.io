<template>
  <div class="drawer__container" :class="getDrawerDirection()">
    <div @click="close" ref="drawerBackground" class="drawer__background"></div>
    <div ref="drawer" class="drawer" :class="getAnimationDirection()">
      <div class="d-flex align-items-center justify-content-end pt-3 pb-3">
        <IconButton
          @clicked="close"
          size="xsmall"
          icon-style="fill: gray;"
          :name="closeIconName"
        ></IconButton>
      </div>
      <div class="d-flex flex-column">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton";
export default {
  components: {
    IconButton,
  },
  props: {
    direction: {
      type: String,
      default: "right",
    },
    closeIconName: {
      type: String,
      default: "Cross",
    },
  },

  methods: {
    getDrawerDirection() {
      return `drawer--${this.direction}`;
    },
    getAnimationDirection() {
      return `drawer--${this.direction}Enter`;
    },
    close() {
      this.$refs.drawer.classList.add(`drawer--${this.direction}Exit`);
      this.$refs.drawerBackground.classList.add(`drawer--fadeOut`);
      setTimeout(() => {
        this.$emit("close-menu");
      }, 500);
    },
  },
};
</script>

<style lang="scss" scoped>
$animationDuration: 0.5s;
.drawer {
  position: relative;
  max-width: 300px;
  width: 100%;
  background: white;
  top: 0;
  box-shadow: 0px 0px 10px 1px rgba($color: #000000, $alpha: 0.33);
  z-index: 201;

  &__background {
    position: fixed;
    width: 100vw;
    height: 100vh;
    top: 0;
    left: 0;
    background: rgba($color: #000000, $alpha: 0.33);
    z-index: 200;
    animation-name: fadeInBackground;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
    opacity: 0;
  }

  &__container {
    position: fixed;
    width: 100vw;
    height: 100vh;
    top: 0;
    left: 0;
    z-index: 199;
    display: flex;
  }

  &--left {
    justify-content: flex-start;
  }

  &--right {
    justify-content: flex-end;
  }

  &--fadeOut {
    animation-name: fadeOutBackground;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }

  &--leftEnter {
    animation-name: appearLeft;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }

  &--rightEnter {
    animation-name: appearRight;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }

  &--rightExit {
    animation-name: dissappearRight;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }

  &--leftExit {
    animation-name: dissappearLeft;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }
}

@keyframes appearLeft {
  from {
    left: -100%;
  }

  to {
    left: 0%;
  }
}

@keyframes appearRight {
  from {
    right: -100%;
  }

  to {
    right: 0%;
  }
}

@keyframes dissappearLeft {
  from {
    left: 0;
  }

  to {
    left: -100%;
  }
}

@keyframes dissappearRight {
  from {
    right: 0;
  }

  to {
    right: -100%;
  }
}

@keyframes fadeInBackground {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes fadeOutBackground {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}
</style>