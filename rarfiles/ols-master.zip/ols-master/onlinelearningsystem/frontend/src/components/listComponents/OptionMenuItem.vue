<template>
  <a :href="to" class="item">
    <slot></slot>
  </a>
</template>

<script>
export default {
  props: {
    to: {
      type: String,
      default: "/",
    },
  },
};
</script>

<style lang="scss" scoped>
.item {
  padding: 1rem;
  transition: background 0.1s ease-in-out;
  text-decoration: none;
  color: $secondaryColorOpposite;
  &:hover {
    background: rgba($color: #000000, $alpha: 0.16);
  }
}
</style>