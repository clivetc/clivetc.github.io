<template>
  <a class="link body body--1" :href="item.link">{{ item.name }}</a>
</template>

<script>
export default {
  props: ["item"],
};
</script>

<style lang="scss" scoped>
.link {
  margin-right: 1.5rem;
  text-decoration: none;
  font-weight: 500;

  transition: color 0.2s ease-in-out;
  &:hover {
    color: $primaryCompliment;
  }
}
.body {
  color: $secondaryColor;

  &--1 {
    font-family: unquote("Roboto");
    font-size: 16;
  }

  &--2 {
    font-family: unquote("Roboto");
    font-size: 14;
  }

  &--invert {
    color: $secondaryColorOpposite;
  }
}
</style>