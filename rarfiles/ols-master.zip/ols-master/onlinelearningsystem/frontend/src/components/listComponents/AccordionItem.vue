<template>
  <div class="accordion-item p-2">
    <slot></slot>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.accordion-item {
  transition: background 0.2s ease-in-out;
  cursor: pointer;
  &:hover {
    background: lightgray;
  }
}
</style>