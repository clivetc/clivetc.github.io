<template>
  <div class="list">
    <NavLink v-for="item in items" :key="item" :item="item"></NavLink>
  </div>
</template>

<script>
import NavLink from "@/components/listComponents/NavLink";
export default {
  components: {
    NavLink,
  },
  props: ["items"],
  mounted() {
    console.log(this.items);
  },
};
</script>

<style lang="scss" scoped>
.list {
  display: flex;
  flex-flow: row;

  &--column {
    flex-flow: column;
  }
}
</style>