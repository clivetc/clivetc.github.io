<template>
  <div class="draweritem d-flex align-items-center justify-content-between">
    <div class="draweritem__icon col-2">
      <Icon v-if="hasIcon" :is="iconName"></Icon>
    </div>
    <div class="draweritem__slot col-10">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import * as Icon from "@/components/iconComponents";

export default {
  components: {
    ...Icon,
  },
  props: {
    hasIcon: {
      type: Boolean,
      default: false,
    },
    iconName: {
      type: String,
      default: "",
    },
  },
};
</script>

<style lang="scss" scoped>
.draweritem {
  padding: 1rem 0.5rem;
  transition: background 0.1s ease-in-out;
  cursor: pointer;
  &:hover {
    background: rgba($color: #000000, $alpha: 0.16);
  }
}
</style>