<template>
  <div class="option-menu">
    <div>
      <IconButton
        @clicked="openMenu"
        :size="iconSize"
        :color="iconColor"
        :name="menuIcon"
      ></IconButton>
    </div>
    <div
      ref="menu"
      :class="getAnimationClass()"
      v-if="open"
      class="option-menu__list"
    >
      <slot></slot>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton";
export default {
  components: {
    IconButton,
  },
  props: {
    menuIcon: {
      type: String,
      default: "Options",
    },
    iconColor: {
      type: String,
      default: "black",
    },
    iconSize: {
      type: String,
      default: "small",
    },
  },
  data() {
    return {
      open: false,
      animationClass: "menu--open",
    };
  },
  mounted() {
    document.querySelector("html").addEventListener("click", (event) => {
      if (
        !event.target.classList.contains("option-menu__list") &&
        this.open == true
      ) {
        if (this.$refs.menu.classList.contains("can-close")) {
          this.animationClass = "menu--close";
          setTimeout(() => {
            this.$refs.menu.classList.remove("can-close");
            this.open = false;
          }, 200);
        }
      }
    });
  },
  methods: {
    openMenu() {
      if (!this.open) {
        this.open = true;
        this.animationClass = "menu--open";
        setTimeout(() => {
          this.$refs.menu.classList.add("can-close");
        }, 200);
      } else {
        this.animationClass = "menu--close";
        setTimeout(() => {
          this.$refs.menu.classList.remove("can-close");
          this.open = false;
        }, 200);
      }
    },
    closeThis() {
      if (this.open) {
        this.animationClass = "menu--close";
      }
    },
    getAnimationClass() {
      return this.animationClass;
    },
  },
};
</script>

<style lang="scss" scoped>
$animationDuration: 0.2s;
.option-menu {
  position: relative;
  &__list {
    position: absolute;
    display: flex;
    flex-flow: column;
    box-shadow: 0px 3px 5px 1px rgba($color: #000000, $alpha: 0.33);
    background: white;
    width: 165px;
    height: auto;
    right: 50%;
    z-index: 100;
    border-radius: 4px;
  }
}

.menu {
  &--open {
    animation-name: animateIn;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }

  &--close {
    animation-name: animateOut;
    animation-duration: $animationDuration;
    animation-fill-mode: forwards;
  }
}

@keyframes animateIn {
  from {
    transform-origin: right top;
    transform: scale(0);
  }

  to {
    transform-origin: right top;
    transform: scale(1);
  }
}

@keyframes animateOut {
  from {
    transform-origin: right top;
    transform: scale(1);
  }

  to {
    transform-origin: right top;
    transform: scale(0);
  }
}
</style>