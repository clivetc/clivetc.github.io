<template>
  <div class="pl-3 pr-3 mt-1 mb-1">
    <div
      @click="toggleAccordion"
      class="accordion__header d-flex justify-content-between align-items-center pt-2 pb-2"
    >
      <span>{{ title }}</span>
      <div class="accordion__drawer">
        <DownArrow></DownArrow>
      </div>
    </div>
    <div v-if="open">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import DownArrow from "../iconComponents/DownArrow";
export default {
  components: {
    DownArrow,
  },
  props: {
    title: {
      type: String,
      default: "",
      required: true,
    },
  },
  data() {
    return {
      open: false,
    };
  },
  methods: {
    toggleAccordion() {
      this.open = !this.open;
    },
  },
};
</script>

<style lang="scss" scoped>
.accordion {
  &__header {
    cursor: pointer;
  }

  &__drawer {
  }
}
</style>