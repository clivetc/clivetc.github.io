<template>
  <div
    class="button--hover button"
    :class="`${this.size}`"
    @click="emitButtonClick"
  >
    <Icon :style="iconStyle" :class="getIconColor()" :is="name"></Icon>
  </div>
</template>

<script>
import * as Icon from "@/components/iconComponents";
export default {
  components: {
    ...Icon,
  },
  props: {
    name: {
      type: String,
      required: true,
      default: "",
    },
    color: {
      type: String,
      default: "primary",
    },
    size: {
      type: String,
      default: "small",
    },
    iconStyle: {
      type: String,
      default: "",
    },
  },

  methods: {
    getIconColor() {
      return `${this.color}`;
    },
    emitButtonClick() {
      this.$emit("clicked");
    },
  },
};
</script>

<style lang="scss" scoped>
.button {
  cursor: pointer;
  margin: 0rem 0.5rem;
  padding: 0.5rem;

  &--hover {
    transition: background 0.2s ease-in-out;
    border-radius: 50%;

    svg {
      margin: 0;
      width: 100%;
      height: 100%;
    }

    &:hover {
      background: rgba($color: #000000, $alpha: 0.16);
    }
  }
}

.primary {
  fill: $primaryColor;
}

.secondary {
  fill: $secondaryColor;
}

.black {
  fill: black;
}

.white {
  fill: white;
}

.xsmall {
  width: 1.75rem;
  height: 1.75rem;
}

.small {
  width: 2.2rem;
  height: 2.2rem;
}

.medium {
  width: 3rem;
  height: 2.2rem;
}

.large {
  width: 4rem;
  height: 2.2rem;
}
</style>