<template>
  <a :href="to" :class="getButtonClass()">
    <slot></slot>
  </a>
</template>

<script>
export default {
  props: {
    type: {
      type: String,
      default: "primary",
    },
    size: {
      type: String,
      default: "medium",
    },
    shadow: {
      type: Boolean,
      default: true,
    },
    to: {
      type: String,
      default: "/",
    },
  },

  methods: {
    getButtonClass() {
      let classList = `${this.type} button button--${this.size} button--hover-${this.type}`;

      if (this.shadow) classList += " button--shadow";
      return classList;
    },
  },
};
</script>

<style lang="scss" scoped>
.button {
  font-family: unquote("Roboto");
  width: 100%;
  border-radius: 0.3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: 400;
  letter-spacing: 1.25;
  cursor: pointer;
  transition: background 0.1s ease-in-out, color 0.1s ease-in-out;
  text-transform: uppercase;
  text-decoration-line: none;
  &--small {
    padding: 0.7rem;
    font-size: 12;
  }

  &--medium {
    padding: 1rem;
    font-size: 14;
  }

  &--large {
    padding: 1.3rem;
    font-size: 16;
  }

  &--shadow {
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
  }

  &--hover-primary {
    &:hover {
      background: $secondaryColor;
      color: $secondaryColorOpposite;
    }
  }

  &--hover-secondary {
    &:hover {
      background: $primaryColor;
      color: $secondaryColor;
    }
  }

  &--hover-compliment {
    &:hover {
      background: $primaryComplimentShade;
      color: $secondaryColor;
    }
  }
}

.primary {
  background: $primaryColor;
  color: $secondaryColor;
}

.secondary {
  background: $secondaryColor;
  color: $secondaryColorOpposite;
}

.compliment {
  background: $primaryCompliment;
  color: $secondaryColor;
}
</style>