<template>
  <button :class="getButtonClass()">
    <slot></slot>
  </button>
</template>

<script>
export default {
  props: {
    type: {
      type: String,
      default: "primary",
    },
    size: {
      type: String,
      default: "medium",
    },
    shadow: {
      type: Boolean,
      default: true,
    },
  },

  methods: {
    getButtonClass() {
      let classList = `${this.type} button button--${this.size} button--hover-${this.type}`;

      if (this.shadow) classList += " button--shadow";
      return classList;
    },
  },
};
</script>

<style lang="scss" scoped>
.button {
  font-family: unquote("Roboto");
  width: 100%;
  border-radius: 0.3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: 400;
  letter-spacing: 1.25;
  cursor: pointer;
  transition: background 0.1s ease-in-out, color 0.1s ease-in-out;
  text-transform: uppercase;
  border: none;

  &--small {
    padding: 0.7rem;
    font-size: 0.75rem;
  }

  &--medium {
    padding: 1rem;
    font-size: 0.9rem;
  }

  &--large {
    padding: 1.3rem;
    font-size: 1rem;
  }

  &--shadow {
    box-shadow: 0 0.6rem 2.125rem rgba(0, 0, 0, 0.19),
      0 0.33rem 0.33rem rgba(0, 0, 0, 0.23);
  }

  &--hover-primary {
    &:hover {
      background: $secondaryColor;
      color: $secondaryColorOpposite;
    }
  }

  &--hover-secondary {
    &:hover {
      background: $primaryColor;
      color: $secondaryColor;
    }
  }

  &--hover-compliment {
    &:hover {
      background: $primaryComplimentShade;
      color: $secondaryColor;
    }
  }
}

.primary {
  background: $primaryColor;
  color: $secondaryColor;
}

.secondary {
  background: $secondaryColor;
  color: $secondaryColorOpposite;
}

.compliment {
  background: $primaryCompliment;
  color: $secondaryColor;
}
</style>