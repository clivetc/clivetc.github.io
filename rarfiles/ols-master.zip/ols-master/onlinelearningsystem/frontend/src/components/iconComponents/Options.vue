<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="4"
    height="16"
    viewBox="0 0 4 16"
  >
    <path
      id="_Color"
      data-name=" ↳Color"
      d="M2,16a2,2,0,1,1,2-2A2,2,0,0,1,2,16Zm0-6A2,2,0,1,1,4,8,2,2,0,0,1,2,10ZM2,4A2,2,0,1,1,4,2,2,2,0,0,1,2,4Z"
    />
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>