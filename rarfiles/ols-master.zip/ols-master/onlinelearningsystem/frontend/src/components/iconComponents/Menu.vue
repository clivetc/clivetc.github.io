<template>
  <!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
  <svg
    version="1.1"
    id="Capa_1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 341.333 341.333"
    style="enable-background: new 0 0 341.333 341.333"
    xml:space="preserve"
  >
    <g>
      <g>
        <rect y="277.333" width="341.333" height="42.667" />
      </g>
    </g>
    <g>
      <g>
        <rect y="149.333" width="341.333" height="42.667" />
      </g>
    </g>
    <g>
      <g>
        <rect y="21.333" width="341.333" height="42.667" />
      </g>
    </g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
    <g></g>
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>