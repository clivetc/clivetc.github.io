<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="7.4"
    height="12"
    viewBox="0 0 7.4 12"
  >
    <path
      id="_Color"
      data-name=" ↳Color"
      d="M7.4,1.41,5.992,0,0,6l5.992,6L7.4,10.59,2.826,6Z"
    />
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>