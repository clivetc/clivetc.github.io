<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
  >
    <path
      id="_Color"
      data-name=" ↳Color"
      d="M10,20A10,10,0,1,1,20,10,10.011,10.011,0,0,1,10,20ZM9,13v2h2V13ZM9,5v6h2V5Z"
      transform="translate(0 0)"
    />
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>