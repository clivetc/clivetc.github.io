<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="12"
    height="7.4"
    viewBox="0 0 12 7.4"
  >
    <path
      id="_Color"
      data-name=" ↳Color"
      d="M10.59,0,6,4.574,1.41,0,0,1.408,6,7.4l6-5.992Z"
    />
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>