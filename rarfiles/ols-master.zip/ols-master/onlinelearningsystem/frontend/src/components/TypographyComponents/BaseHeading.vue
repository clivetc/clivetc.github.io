<template>
  <p :class="`headline headline--${level} headline--${invert}`">
    <slot></slot>
  </p>
</template>

<script>
export default {
  props: ["level", "invert"],
};
</script>

<style lang="scss" scoped>
.headline {
  color: $secondaryColorOpposite;

  &--1 {
    font-family: unquote("Roboto");
    font-size: calc(var(--font-size) * 6px);
  }
  &--2 {
    font-family: unquote("Roboto");
    font-size: calc(var(--font-size) * 3.75px);
  }
  &--3 {
    font-family: unquote("Roboto");
    font-size: calc(var(--font-size) * 3px);
  }
  &--4 {
    font-family: unquote("Roboto");
    font-size: calc(var(--font-size) * 2.125px);
  }
  &--5 {
    font-family: unquote("Roboto");
    font-size: calc(var(--font-size) * 1.5px);
  }
  &--6 {
    font-family: unquote("Roboto");
    font-size: 1.25rem;
    font-size: calc(var(--font-size) * 1.25px);
  }
  &--invert {
    color: $secondaryColor;
  }
}
</style>