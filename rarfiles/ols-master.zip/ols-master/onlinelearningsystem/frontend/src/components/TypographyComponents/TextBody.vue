<template>
  <div :class="`body body--${level}`">
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    level: {
      type: String,
      default: "1",
    },
  },
};
</script>

<style lang="scss" scoped>
.body {
  color: $secondaryColor;

  &--1 {
    font-family: unquote("Roboto");
    font-size: 16;
  }

  &--2 {
    font-family: unquote("Roboto");
    font-size: 14;
  }

  &--invert {
    color: $secondaryColorOpposite;
  }
}
</style>