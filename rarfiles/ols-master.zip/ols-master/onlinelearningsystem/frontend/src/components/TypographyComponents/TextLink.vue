<template>
  <a class="link" :class="getLinkType()" :href="to">
    <slot></slot>
  </a>
</template>

<script>
export default {
  props: ["to", "type"],
  methods: {
    getLinkType() {
      return `link--${this.type}`;
    },
  },
};
</script>

<style lang="scss" scoped>
.link {
  font-size: 1rem;
  color: $primaryColor;

  transition: color 0.2s ease-in-out;

  &--secondary {
    color: $secondaryColor;
  }

  &--primary {
    color: $primaryColor;
  }

  &--compliment {
    color: $primaryCompliment;
  }

  &:focus {
    color: $primaryCompliment;
  }

  &:active {
    color: $primaryCompliment;
  }

  &:hover {
    color: $primaryCompliment;
  }
}
</style>