<template>
  <div
    v-if="active"
    ref="notification"
    class="type d-flex"
    :class="getNotificationClass()"
  >
    {{ message }}
    <div class="d-flex justify-content-end align-items-center">
      <IconButton
        size="small"
        color="white"
        name="Cross"
        @clicked="closeNotification"
      ></IconButton>
    </div>
  </div>
</template>

<script>
import IconButton from "../buttonComponents/IconButton";
export default {
  components: {
    IconButton,
  },

  props: ["type", "message"],
  data() {
    return {
      active: true,
    };
  },
  mounted() {
    setTimeout(() => {
      this.$refs.notification.classList.add("type--animate-out");
      this.removeNotification();
    }, 3000);
  },
  methods: {
    getNotificationClass() {
      return `type--${this.type}`;
    },

    closeNotification() {
      this.$refs.notification.classList.add("type--animate-out");

      this.removeNotification();
      console.log("clicked");
    },

    removeNotification() {
      setTimeout(() => {
        this.active = false;
      }, 1000);
    },
  },
};
</script>

<style lang="scss" scoped>
.type {
  position: relative;
  padding: 1rem 1.5rem;
  max-width: 300px;
  line-height: 1.5;
  border-radius: 8px;
  animation-name: animateIn;
  animation-duration: 1s;
  animation-fill-mode: forwards;
  padding-right: 0.5rem;
  z-index: 999999;
  margin-bottom: 1rem;
  &--success {
    background: rgb(32, 199, 88);
    color: white;
  }

  &--error {
    background: rgb(255, 116, 116);
    color: white;
  }

  &--info {
    background: dodgerblue;
    color: white;
  }

  &--animate-out {
    animation-name: animateOut;
    animation-duration: 1s;
    animation-fill-mode: forwards;
  }
}

@keyframes animateIn {
  from {
    right: -100%;
  }

  to {
    right: 1%;
  }
}

@keyframes animateOut {
  from {
    right: 1%;
  }

  to {
    right: -100%;
  }
}
</style>