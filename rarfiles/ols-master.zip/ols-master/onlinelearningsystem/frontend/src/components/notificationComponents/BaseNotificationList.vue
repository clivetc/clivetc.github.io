<template>
  <div class="notification-wrapper">
    <baseapinotification
      v-for="(notification, index) in notifications"
      :key="index"
      :type="notification.type"
      :message="notification.message"
    >
    </baseapinotification>
  </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  computed: {
    ...mapGetters({
      notifications: "notificationStore/getNotifications",
    }),
  },
};
</script>

<style lang="scss" scoped>
.notification-wrapper {
  display: flex;
  flex-flow: column;
  align-items: flex-end;
  position: fixed;
  bottom: 0;
  right: 0;
  z-index: 9999999;
}
</style>