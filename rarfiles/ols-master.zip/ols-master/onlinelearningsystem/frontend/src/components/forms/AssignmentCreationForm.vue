<template>
  <div class="d-flex flex-column">
    <base-heading level="4"> Create Assignment</base-heading>
    <div class="d-flex flex-column">
      <div class="mb-2">
        <text-input
          label="Assignment Title"
          name="assignment_title"
          type="text"
          @changed="set_title"
        ></text-input>
      </div>
      <label class="mb-2" for="assignment_due">
        Assignment Description
        <div class="mb-2">
          <ckeditor v-model="assignment_description"></ckeditor>
        </div>
      </label>

      <label class="mb-2" for="assignment_due">
        Assignment Due
        <div
          class="mb-2 input-group date datetimepicker"
          id="datetimepicker5"
          data-target-input="nearest"
        >
          <input
            type="text"
            class="form-control datetimepicker-input"
            name="assignment_due"
            data-target="#datetimepicker5"
            v-model="assignment_due"
          />
          <div
            class="input-group-append"
            data-target="#datetimepicker5"
            data-toggle="datetimepicker"
          >
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
          </div>
        </div>
      </label>
      <div class="mb-2">
        <text-input
          label="Assignment Points"
          name="assignment_points"
          type="number"
          max="100"
          @changed="set_points"
        ></text-input>
      </div>
      <div class="mb-2">
        <default-button @clicked="submit" type="compliment"
          >Create Assignment</default-button
        >
      </div>
    </div>
  </div>
</template>

<script>
import DefaultButton from "../buttonComponents/DefaultButton.vue";
import TextInput from "../formComponents/textInput.vue";
import BaseHeading from "../TypographyComponents/BaseHeading.vue";
import { mapGetters } from "vuex";
export default {
  components: {
    BaseHeading,
    TextInput,
    DefaultButton,
  },
  computed: {
    ...mapGetters({
      course: "coursesStore/getCourseState",
    }),
  },
  data() {
    return {
      assignment_title: "",
      assignment_description: "",
      assignment_due: "01/22/2021 1:23 AM",
      assignment_points: "",
    };
  },
  methods: {
    submit() {
      const {
        assignment_title,
        assignment_description,
        assignment_due,
        assignment_points,
        course,
      } = this;
      console.log(course.pk);
      this.$store.dispatch("assignmentStore/createAssignment", {
        course_id: course.pk,
        assignment_title: assignment_title,
        assignment_description: assignment_description,
        assignment_due: assignment_due,
        assignment_points: assignment_points,
      });
    },
    set_title(text) {
      this.assignment_title = text;
    },

    set_points(text) {
      this.assignment_points = text;
    },
  },
};
</script>

<style lang="scss" scoped>
</style>