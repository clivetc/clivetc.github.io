<template>
  <div class="d-flex flex-column align-items-center p-3">
    <base-heading level="4">Create a class</base-heading>
    <form method="POST" class="d-flex flex-column" action="/course/create">
      <csrf-token></csrf-token>
      <label for="course_name">
        Course Name
        <input type="text" name="course_name" id="" />
      </label>
      <label for="course_description">
        Course Description
        <input type="text" name="course_description" id="" />
      </label>
      <label for="course_code">
        Course Code
        <input type="text" name="course_code" id="" />
      </label>
      <label for="course_start">
        Course Start
        <div
          class="input-group date datetimepicker"
          id="datetimepicker4"
          data-target-input="nearest"
        >
          <input
            type="text"
            class="form-control datetimepicker-input"
            name="course_start"
            data-target="#datetimepicker4"
          />
          <div
            class="input-group-append"
            data-target="#datetimepicker4"
            data-toggle="datetimepicker"
          >
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
          </div>
        </div>
      </label>
      <label for="course_end">
        Course End
        <div
          class="input-group date datetimepicker"
          id="datetimepicker5"
          data-target-input="nearest"
        >
          <input
            type="text"
            class="form-control datetimepicker-input"
            name="course_end"
            data-target="#datetimepicker5"
          />
          <div
            class="input-group-append"
            data-target="#datetimepicker5"
            data-toggle="datetimepicker"
          >
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
          </div>
        </div>
      </label>
      <button type="submit">Create</button>
    </form>
  </div>
</template>

<script>
import CsrfToken from "../formComponents/csrfToken.vue";
import BaseHeading from "../TypographyComponents/BaseHeading.vue";
export default {
  components: { BaseHeading, CsrfToken },
};
</script>

<style lang="scss" scoped>
</style>