<template>
  <container
    class="primaryBg seperate-on-mobile"
    :center="true"
    margin="0"
    padding="0"
    :card="true"
  >
    <!-- Desktop Start -->
    <Wrapper max-width="100%" padding="0rem" class="d-lg-flex d-none">
      <container class="col-2 col-md-2" :center="true">
        <Logo width="128px"></Logo>
      </container>

      <container class="col"> </container>

      <!-- Auth View Start -->
      <container class="col-auto d-flex align-items-center" :left="false">
        <div class="d-flex align-items-center">
          <TextBody class="mr-2">
            {{ userProfile.first_name | capitalize }}
          </TextBody>
          <TextBody>
            {{ userProfile.last_name | capitalize }}
          </TextBody>
        </div>
        <div>
          <Avatar></Avatar>
        </div>
        <div>
          <OptionMenu iconColor="white">
            <OptionMenuItem to="/user/dashboard">Dashboard</OptionMenuItem>
            <OptionMenuItem>Courses</OptionMenuItem>
            <OptionMenuItem>Settings</OptionMenuItem>
          </OptionMenu>
        </div>

        <div>
          <IconButton
            @clicked="logout"
            color="white"
            size="small"
            name="Logout"
          ></IconButton>
        </div>
      </container>

      <!-- Auth View End -->
    </Wrapper>
    <!-- Desktop End -->
    <!-- Mobile Start -->
    <Wrapper padding="0rem" class="d-flex d-lg-none">
      <container class="col-4">
        <Logo width="128px"></Logo>
      </container>
      <container class="col-8" :left="false">
        <Container>
          <IconButton
            @clicked="openMenu"
            name="Menu"
            color="secondary"
            size="small"
          ></IconButton>
        </Container>
        <MobileNav @close-menu="mobileClose" v-if="mobileOpen"></MobileNav>
      </container>
    </Wrapper>
    <!-- Mobile End -->
  </container>
</template>

<script>
import Container from "@/components/layoutComponents/Container";

import Logo from "@/components/mainComponents/Logo";
import IconButton from "@/components/buttonComponents/IconButton";
import MobileNav from "@/components/mainComponents/MobileNav";
import TextBody from "../TypographyComponents/TextBody";
import Avatar from "../profileComponents/Avatar";
import OptionMenu from "../listComponents/OptionMenu";
import OptionMenuItem from "../listComponents/OptionMenuItem";

export default {
  components: {
    Container,

    Logo,
    IconButton,
    MobileNav,
    TextBody,
    Avatar,
    OptionMenu,
    OptionMenuItem,
  },
  data() {
    return {
      mobileOpen: false,
    };
  },

  methods: {
    openMenu() {
      this.mobileOpen = !this.mobileOpen;
    },
    mobileClose() {
      this.mobileOpen = false;
    },
    logout() {
      window.location.href = "/user/logout";
    },
  },
};
</script>

<style lang="scss">
.primaryBg {
  background: $primaryColor;
}

.visible-on-mobile {
  display: none !important;
  @media (max-width: 700px) {
    display: block !important;
  }
}

.hide-on-mobile {
  display: initial;
  @media (max-width: 700px) {
    display: none !important;
  }
}

.seperate-on-mobile {
  justify-content: initial;
  @media (max-width: 700px) {
    justify-content: space-between !important;
  }
}
</style>