import axios from "axios";
import store from "../store";

const api = axios.create({
    headers: {
        'X-CSRFToken': window.csrftoken
    },
});

api.interceptors.response.use((response) => {
    if (response.data.type) {
        store.dispatch("notificationStore/display", response.data)
    }
    return response;
}, (error) => {
    // whatever you want to do with the error
    if (error.response.data) {
        store.dispatch('notificationStore/display', error.response.data);

    }
    throw error;
});

export default api;