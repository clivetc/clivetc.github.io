/* eslint-disable */
import Vue from "vue";
import store from "./store";
import Wrapper from "./components/layoutComponents/Wrapper.vue";
import filter from "./filters";
import datas from "./data";
import CKEditor from 'ckeditor4-vue';

window.Dropzone = require('./vendor/dropzone-5.7.0');

window.Dropzone.autoDiscover = false;



window.Vue = Vue;

Vue.config.productionTip = false;

import "./globalComponents";

Vue.component("Wrapper", Wrapper);

Vue.mixin({
  data() {
    return {
      ...datas,
    };
  },
  filters: {
    ...filter,
  },
});

Vue.use(CKEditor);


new Vue({
  el: "#app",
  store,
}).$mount("#app");
