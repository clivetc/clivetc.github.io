import Vue from "vue";

const requireComponent = require.context(
    // The relative path of the components folder
    './components',
    // Whether or not to look in subfolders
    true,
    // The regular expression used to match base component filenames
    /Base[A-Z]\w+\.(vue|js)$/
)


requireComponent.keys().forEach(fileName => {

    const requiredComponent = requireComponent(fileName);

    const componentName = fileName.split('/').pop().replace('-', "").replace(".vue", "").toLowerCase();

    Vue.component(componentName, requiredComponent.default || requiredComponent);

});


