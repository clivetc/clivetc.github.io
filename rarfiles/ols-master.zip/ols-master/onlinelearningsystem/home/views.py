from django.shortcuts import render
from django.views.generic.base import TemplateView
from usermanager.helpers.usermanager import UserManager
from django.core import serializers
import json


class IndexTemplateView(TemplateView):
    def get_template_names(self):
        template_name = "index.html"
        return template_name


def home_page(request, *args, **kwargs):

    user_profile = None
    if request.user.is_authenticated:
        user = request.user
        user_profile = get_data_as_json(UserManager.getUserProfile(user))[0]

    return render(
        request,
        "home/index.html",
        {"user_profile": user_profile},
    )


def get_data_as_json(data):
    return json.loads(serializers.serialize("json", [data], ensure_ascii=False))
