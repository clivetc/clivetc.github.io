from posts.models import PostAttachment
from django import forms


class UploadPostAttachmentForm(forms.ModelForm):
    class Meta:
        model = PostAttachment
        fields = ("title", "file")
