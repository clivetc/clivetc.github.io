from Courses.models import Course
from django.contrib.auth.models import User
from posts.models import Post, PostAttachment
from django.db.models.query import QuerySet


class PostManager:
    @staticmethod
    def create_post(post: Post) -> Post:
        initial_post = Post.objects.create(
            user=post.user,
            course=post.course,
            post_type=post.post_type,
            content=post.content,
            resource_id=post.resource_id,
        )
        return initial_post

    @staticmethod
    def get_latest_posts(course: Course) -> QuerySet(Post):
        posts = Post.objects.filter(course=course).order_by("-id")[0:10]
        print(posts)
        return posts