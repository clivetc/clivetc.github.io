from posts.models import Post, PostAttachment


class PostAttachmentManager:
    @staticmethod
    def add_attachement_to_post(post: Post):
        pass