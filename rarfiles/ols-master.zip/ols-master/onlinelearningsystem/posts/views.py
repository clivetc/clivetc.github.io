from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework import viewsets
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.request import Request
from rest_framework.decorators import action
from posts.models import Post, PostAttachment
from posts.serializers.postserializer import PostSerializer
from posts.helpers.PostManager import PostManager
from Courses.models import Course
from django.contrib.auth.models import User
from .forms.UploadPostAttachmentForm import UploadPostAttachmentForm

# Create your views here.


class PostViewSet(viewsets.GenericViewSet):
    queryset = Post.objects.all()
    permission_classes = [IsAuthenticated]
    serializer_class = PostSerializer

    @action(detail=True, methods=["DELETE"])
    def post_delete(self, request, pk):

        post = self.get_object()
        post.delete()
        return Response({"type": "success", "message": "Post Deleted Successfully"})

    @action(detail=False, methods=["POST"])
    def upload(self, request):

        file = request.FILES["upload"]
        fileTitle = file.name
        attachment = PostAttachment(title=fileTitle, file=file)

        try:
            attachment.full_clean()
            attachment.save()
            return Response(
                {
                    "uploaded": 1,
                    "fileName": attachment.title,
                    "url": "/static" + attachment.file.url,
                },
                200,
            )
        except:
            return Response(
                {"uploaded": 0, "fileName": "foo.jpg", "url": "/files/foo.jpg"}, 400
            )
