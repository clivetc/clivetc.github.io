from django.test import TestCase
from posts.models import Post
from django.contrib.auth.models import User
from Courses.models import Course
from posts.helpers.PostManager import PostManager
from usermanager.helpers.usermanager import UserManager
from Courses.coursemanager.coursemanager import CourseManager
import datetime
from django.utils import timezone

# Create your tests here.


class PostTestCase(TestCase):
    def setUp(self):
        user = User.objects.create_user(
            username="Unal Inanli",
            password="campio",
            email="example@example.com",
            first_name="Unal",
            last_name="Inanli",
        )
        CourseManager.create_course(
            course_name="New Course",
            course_code="CIS 331",
            course_description="Random Description",
            course_start=datetime.datetime.now(tz=timezone.utc),
            teacher=user,
            course_end=datetime.datetime.now(tz=timezone.utc),
        )

    def test_add_post(self):
        user = User.objects.get(pk=1)
        course = Course.objects.get(pk=1)

        post = PostManager.create_post(
            Post(
                user=user,
                course=course,
                post_type="REGULAR",
                content="this is a regular post",
            )
        )

        self.assertIsNotNone(post)
        self.assertIsInstance(post, Post)

        print(
            "User: {}, Course: {}, Post Content: {}, Post Type: {}".format(
                post.user.username,
                post.course.course_code,
                post.content,
                post.post_type,
            ),
        )
