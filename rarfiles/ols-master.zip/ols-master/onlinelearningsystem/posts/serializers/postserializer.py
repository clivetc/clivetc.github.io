from rest_framework import serializers
from posts.models import Post
from usermanager.serializers.UserSerializer import UserSerializer
from usermanager.helpers.usermanager import UserManager


class PostSerializer(serializers.ModelSerializer):

    user = UserSerializer()

    class Meta:
        model = Post
        fields = "__all__"
        depth = 1
