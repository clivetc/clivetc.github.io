from django.db import models
from django.contrib.auth.models import User
from Courses.models import Course

# Create your models here.


class Post(models.Model):

    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    post_types = models.TextChoices("post_type", "ASSIGNMENT ANOUNCEMENT QUIZ REGULAR")
    post_type = models.CharField(
        max_length=50, blank=False, choices=post_types.choices, default="REGULAR"
    )
    content = models.TextField(max_length=250)
    resource_id = models.IntegerField(null=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)


class PostAttachment(models.Model):

    title = models.CharField(max_length=80, default="null")
    file = models.FileField(upload_to="media/", default="null")

    class Meta:
        ordering = ["title"]

    def __str__(self):
        return f"{self.title}"