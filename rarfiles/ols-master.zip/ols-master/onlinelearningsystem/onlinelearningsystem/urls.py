"""onlinelearningsystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include, re_path
from home.views import IndexTemplateView, home_page
from usermanager import views
from Courses import views as course_views
from posts import views as post_views
from usermanager import views as user_views
from assignments import views as assignment_views
from rest_framework_nested import routers

router = routers.SimpleRouter()
router.register(r"courses", course_views.CourseViewSet)

courses_routes = routers.NestedSimpleRouter(
    router, r"courses", course_views.CourseViewSet, lookup="courses"
)
courses_routes.register(
    r"assignment",
    assignment_views.AssignmentViewSet,
)

assignments_routes = routers.NestedSimpleRouter(
    courses_routes, r"assignment", lookup="assignment"
)
assignments_routes.register(
    r"submitted", assignment_views.SubmittedAssignmentViewSet, basename="submitted"
)

router.register(r"posts", post_views.PostViewSet)
router.register(r"user", user_views.UserViewSet)

urlpatterns = [
    path("api/", include(router.urls)),
    path(r"api/", include(courses_routes.urls)),
    path(r"api/", include(assignments_routes.urls)),
    path("", home_page),
    path("user/", include("usermanager.urls")),
    path("course/", include("Courses.urls")),
    path("admin/", admin.site.urls),
]
