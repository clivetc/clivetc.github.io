from django.db import models

# Create your models here.
class Quiz(models.Model):
    Name = models.CharField(max_length=2)
    Description = models.CharField(max_length=2)
    Image = models.ImageField()
    Slug = models.SlugField()
    Roll_Out = models.BooleanField()
    Timestamp = models.DateTimeField()
