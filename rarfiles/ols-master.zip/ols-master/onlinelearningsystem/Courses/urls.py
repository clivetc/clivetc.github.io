"""onlinelearningsystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from .views import (
    create_course,
    course_view,
    assignment_view,
    assignments_view,
    grade_view,
    submitted_assignments_view,
    submitted_assignment_view,
)

urlpatterns = [
    path("create", create_course),
    path("view/<int:course_id>/", course_view),
    path(
        "view/<int:course_id>/assignments/<int:assignment_id>/submitted/",
        submitted_assignments_view,
    ),
    path(
        "view/<int:course_id>/assignments/<int:assignment_id>/submitted/view/",
        submitted_assignment_view,
    ),
    path("view/<int:course_id>/assignments/<int:assignment_id>/", assignment_view),
    path("view/<int:course_id>/assignments/<int:assignment_id>/grade", grade_view),
    path("view/<int:course_id>/assignments/", assignments_view),
]
