from rest_framework import serializers
from Courses.models import Course


class CourseSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Course
        fields = [
            "id",
            "course_name",
            "course_code",
            "course_description",
            "course_start",
            "course_end",
            "invite_code",
        ]
