from Courses.models import Course
from datetime import datetime
import random
import string
from django.contrib.auth.models import User
from django.db.models.query import QuerySet


class CourseManager:
    @staticmethod
    def create_course(
        course_name: str,
        course_description: str,
        course_start: datetime,
        course_end: datetime,
        course_code: str,
        teacher,
    ):

        invite_code = get_random_alphanumeric_string(6)
        course = Course(
            course_name=course_name,
            course_code=course_code,
            course_description=course_description,
            course_start=course_start,
            course_end=course_end,
            invite_code=invite_code,
        )
        course.save()
        course.user.add(teacher)
        return course

    @staticmethod
    def add_student_to_course(course: Course, user):
        print(user)
        student = User.objects.get(pk=user)
        course.user.add(student)
        return True

    @staticmethod
    def get_course(id: int) -> Course:
        return Course.objects.filter(pk=id)

    @staticmethod
    def user_belongs_to_course(user: User, course: Course) -> bool:
        return course[0].user.filter(pk=user.id).count()

    @staticmethod
    def get_user_courses(id: int) -> QuerySet(Course):
        user = User.objects.get(pk=id)
        return Course.objects.filter(user=user)


def get_random_alphanumeric_string(length):
    letters_and_digits = string.ascii_uppercase + string.digits
    result_str = "".join((random.choice(letters_and_digits) for i in range(length)))
    return result_str