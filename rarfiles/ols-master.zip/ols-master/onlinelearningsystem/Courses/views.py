from assignments.serializers.submittedassignmentserializer import (
    SubmittedAssignmentSerializer,
)
from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from rest_framework import permissions
from .models import Course
from .serializers.courseserializer import CourseSerializer
from .coursemanager.coursemanager import CourseManager
from .forms.CreateCourseForm import CreateCourseForm
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from usermanager.helpers.usermanager import UserManager
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.request import Request
from posts.helpers.PostManager import PostManager
from assignments.helpers.assignmentmanager import AssignmentManager
from posts.serializers.postserializer import PostSerializer
from posts.models import Post
from assignments.forms.CreateAssignmetForm import CreateAssignmentForm
from assignments.models import Assignment, SubmittedAssignment
from assignments.serializers.assignmentserializer import AssignmentSerializer
from django.contrib.auth.models import User


class CourseViewSet(viewsets.ModelViewSet):

    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False)
    def specific(self, request, pk=None):
        if request.user.is_authenticated:
            user = request.user
            user_profile = UserManager.getUserProfile(user)
            queryset = Course.objects.filter(
                user=user, user__userprofile__user_type=user_profile.user_type
            )
            serializer = CourseSerializer(queryset, many=True)
            return Response(serializer.data)

    @action(methods=["POST"], detail=False)
    def join(self, request):
        if request.user.is_authenticated:
            user = request.data.get("user")
            code = request.data.get("code")

            course = Course.objects.filter(invite_code=code)

            if not course.exists():
                return Response(
                    {"type": "error", "message": "That class doesnt exist"}, 404
                )

            if course.first().user.filter(pk=user).exists():
                return Response(
                    {"type": "info", "message": "You already enrolled to this class"},
                    400,
                )

            added = CourseManager.add_student_to_course(course.first(), user)

            if not added:
                return Response(
                    {"type": "error", "message": "That class doesnt exist"}, 404
                )

            return Response(
                {
                    "courses": CourseSerializer(
                        CourseManager.get_user_courses(user), many=True
                    ).data,
                    "type": "success",
                    "message": "You have successfully enrolled to {}".format(
                        course.first().course_code
                    ),
                },
                200,
            )

    @action(detail=True, methods=["GET"])
    def post_list(self, request: Request, pk):

        user = request.user
        belongs_to_course = self.get_queryset().filter(
            pk=self.get_object().id, user=user
        )

        if not belongs_to_course.exists():
            return Response({"type": "error", "message": "Forbidden Action"}, 403)

        posts = PostManager.get_latest_posts(self.get_object())

        serializer = PostSerializer(posts, many=True)

        return Response(serializer.data)

    @action(detail=True, methods=["POST"])
    def add_post(self, request: Request, pk):
        user = request.user
        belongs_to_course = self.get_queryset().filter(
            pk=self.get_object().id, user=user
        )

        if not belongs_to_course.exists():
            return Response({"type": "error", "message": "Forbidden Action"}, 403)

        PostManager.create_post(
            post=Post(
                user=user,
                course=self.get_object(),
                content=request.data.get("content"),
                post_type=request.data.get("post_type"),
            )
        )

        posts = PostManager.get_latest_posts(course=self.get_object())

        serializer = PostSerializer(posts, many=True)

        return Response(
            {
                "posts": serializer.data,
                "type": "success",
                "message": "Post successfully created",
            },
            200,
        )

    @action(detail=True, methods=["Post"])
    def create_assignment(self, request, pk):
        user = request.user
        data = CreateAssignmentForm(request.data)
        course = self.get_object()
        if not data.is_valid():
            return Response(
                {
                    "type": "error",
                    "message": data.errors,
                },
                400,
            )

        created_assignment = AssignmentManager.create_assignment(
            Assignment(
                course=course,
                assignment_title=data.clean_assignment_title(),
                assignment_description=data.clean_assignment_description(),
                assignment_points=data.clean_assignment_points(),
                assignment_due=data.clean_due(),
            ),
        )

        if created_assignment:
            PostManager.create_post(
                Post(
                    user=user,
                    course=course,
                    post_type="ASSIGNMENT",
                    content=data.clean_assignment_description(),
                    resource_id=created_assignment.id,
                )
            )

            return Response(
                {"type": "success", "message": "Assignment created successfully"}, 200
            )

        return Response(
            {
                "type": "error",
                "message": "Error during the creation of the assignments",
            },
            400,
        )

    @action(detail=True, methods=["GET"])
    def assignments(self, request, pk):
        course = self.get_object()

        if course.assignment_set.count():
            serializer = AssignmentSerializer(course.assignment_set.all(), many=True)
            return Response(serializer.data)

        return Response({}, 200)


def create_course(request, *args, **kwargs):
    if not request.user.is_authenticated:
        return HttpResponse("Unauthorized", status=401)

    if request.method == "POST":
        cleaned_data = CreateCourseForm(request.POST)
        if cleaned_data.is_valid():
            CourseManager.create_course(
                course_code=cleaned_data.cleaned_data["course_code"],
                course_description=cleaned_data.cleaned_data["course_description"],
                course_start=cleaned_data.clean_start(),
                course_end=cleaned_data.clean_end(),
                course_name=cleaned_data.cleaned_data["course_name"],
                teacher=request.user,
            )
            return render(
                request,
                "user/dashboard.html",
                {
                    "success": "Congratulations you have successfully created your account"
                },
                status=302,
            )

        return render(
            request,
            "user/dashboard.html",
            {"error": "Something went wrong during course creation"},
            status=302,
        )

    return render(request, "user/teacher/courses/create.html")


@login_required(login_url="/user/login")
def course_view(request, course_id=None):
    if not course_id:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    return render(
        request,
        "course/view.html",
        {"course": course},
    )


@login_required(login_url="/user/login")
def assignment_view(request, course_id=None, assignment_id=None):
    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    assignment = AssignmentManager.get_assignment(assignment_id)

    if not assignment:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    serializer = AssignmentSerializer(
        instance=assignment.first(), context={"user": request.user}
    )

    return render(
        request,
        "course/assignment.html",
        {"course": course, "assignment": serializer.data},
    )


@login_required(login_url="/user/login")
def assignments_view(request, course_id=None):
    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    assignments = AssignmentManager.get_course_assignments(course.first())

    if not assignments:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    serializer = AssignmentSerializer(
        instance=assignments, many=True, context={"user": request.user}
    )

    return render(request, "course/assignments.html", {"assignments": serializer.data})


@login_required(login_url="/user/login")
def grade_view(request: Request, course_id=None, assignment_id=None):

    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if request.method == "POST":
        AssignmentManager.grade_assignment(
            request.POST.get("submitted_assignment_id"), request.POST.get("grade")
        )

    assignment = AssignmentManager.get_assignment(assignment_id)

    if not assignment:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    serializer = AssignmentSerializer(
        instance=assignment.first(), context={"user": request.user}
    )

    return redirect(
        "/course/view/{}/assignments/{}/".format(course_id, assignment_id),
        {"course": course, "assignment": serializer.data},
    )


@login_required(login_url="/user/login")
def submitted_assignments_view(request: Request, course_id=None, assignment_id=None):

    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    assignment = AssignmentManager.get_assignment(assignment_id)[0]

    if not assignment:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    submitted_assignments = assignment.submittedassignment_set.all()

    print(submitted_assignments)

    submitted_list = map(
        lambda x: SubmittedAssignmentSerializer(x).data, submitted_assignments
    )

    print(submitted_list)

    return render(
        request, "course/submitted_assignments.html", {"assignments": submitted_list}
    )


@login_required(login_url="/user/login")
def submitted_assignment_view(request: Request, course_id=None, assignment_id=None):
    submitted_id = request.GET["submitted_id"]

    course = CourseManager.get_course(course_id)

    if not course:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    if not CourseManager.user_belongs_to_course(request.user, course):
        return redirect(request.META.get("HTTP_REFERER", "/"))

    assignment = AssignmentManager.get_assignment(assignment_id)[0]

    if request.method == "POST":
        AssignmentManager.grade_assignment(
            request.POST.get("submitted_assignment_id"), request.POST.get("grade")
        )

    if not assignment:
        return redirect(request.META.get("HTTP_REFERER", "/"))

    submitted_assignment = assignment.submittedassignment_set.get(pk=submitted_id)

    serializer = AssignmentSerializer(
        instance=assignment,
        context={"user": User.objects.get(pk=submitted_assignment.user.id)},
    )

    return render(
        request,
        "course/submitted_assignment.html",
        {"assignment": serializer.data},
    )
