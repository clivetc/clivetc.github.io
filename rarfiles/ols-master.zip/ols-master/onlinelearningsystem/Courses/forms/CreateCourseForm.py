from django import forms
from datetime import datetime


class CreateCourseForm(forms.Form):

    course_name = forms.CharField()
    course_description = forms.CharField()
    course_start = forms.CharField()
    course_end = forms.CharField()
    course_code = forms.CharField()

    def clean_start(self):
        start = self.cleaned_data["course_start"]
        return datetime.strptime(start, "%m/%d/%Y %I:%M %p")

    def clean_end(self):
        end = self.cleaned_data["course_end"]
        return datetime.strptime(end, "%m/%d/%Y %I:%M %p")