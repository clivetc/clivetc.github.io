from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Course(models.Model):
    course_name = models.TextField(default="")
    course_code = models.TextField(default="")
    course_description = models.TextField(default="")
    course_start = models.DateTimeField(default="")
    course_end = models.DateTimeField(default="")
    invite_code = models.TextField(max_length=6)
    user = models.ManyToManyField(User)
